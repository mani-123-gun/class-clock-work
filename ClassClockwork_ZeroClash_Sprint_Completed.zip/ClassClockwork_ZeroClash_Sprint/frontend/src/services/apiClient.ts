import {
  Classroom,
  ClashViolation,
  Faculty,
  SolverResult,
  Subject,
  TimetableAllocation,
  TimetableDataset,
} from '../../../shared/types';

const BASE_URL = '/api';

export async function fetchActiveDataset(): Promise<TimetableDataset> {
  const res = await fetch(`${BASE_URL}/dataset/active`);
  if (!res.ok) throw new Error('Failed to load active dataset from server.');
  return res.json();
}

export async function loadPresetDataset(preset: 'demo6' | 'cs8'): Promise<TimetableDataset> {
  const res = await fetch(`${BASE_URL}/dataset/load-preset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ preset }),
  });
  if (!res.ok) throw new Error('Failed to load preset dataset.');
  return res.json();
}

export async function saveDatasetToServer(dataset: TimetableDataset): Promise<TimetableDataset> {
  const res = await fetch(`${BASE_URL}/dataset`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dataset),
  });
  if (!res.ok) throw new Error('Failed to save dataset.');
  return res.json();
}

export async function generateScheduleOnServer(payload: {
  subjects: Subject[];
  faculty: Faculty[];
  classrooms: Classroom[];
  preserveLocked?: boolean;
  lockedAllocations?: TimetableAllocation[];
  lunchPeriod?: number;
}): Promise<{ result: SolverResult; dataset: TimetableDataset }> {
  const res = await fetch(`${BASE_URL}/timetable/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error('CSP solver request failed.');
  return res.json();
}

export async function validateAllocationsOnServer(payload: {
  allocations: TimetableAllocation[];
  subjects: Subject[];
  faculty: Faculty[];
  classrooms: Classroom[];
}): Promise<ClashViolation[]> {
  const res = await fetch(`${BASE_URL}/timetable/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error('Clash validation request failed.');
  const data = await res.json();
  return data.clashes as ClashViolation[];
}
