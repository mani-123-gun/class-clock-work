import React, { useState } from 'react';
import { BookOpen, Building2, Plus, Trash2, Users } from 'lucide-react';
import { Classroom, DAYS_OF_WEEK, DayOfWeek, Faculty, Subject } from '../../../shared/types';

interface ResourceManagerProps {
  subjects: Subject[];
  facultyList: Faculty[];
  classrooms: Classroom[];
  onAddSubject: (subj: Subject) => void;
  onUpdateSubject: (id: string, subj: Subject) => void;
  onDeleteSubject: (id: string) => void;
  onAddFaculty: (fac: Faculty) => void;
  onUpdateFaculty: (id: string, fac: Faculty) => void;
  onDeleteFaculty: (id: string) => void;
  onAddClassroom: (room: Classroom) => void;
  onUpdateClassroom: (id: string, room: Classroom) => void;
  onDeleteClassroom: (id: string) => void;
}

export const ResourceManager: React.FC<ResourceManagerProps> = ({
  subjects,
  facultyList,
  classrooms,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject,
  onAddFaculty,
  onUpdateFaculty,
  onDeleteFaculty,
  onAddClassroom,
  onUpdateClassroom,
  onDeleteClassroom,
}) => {
  const [tab, setTab] = useState<'SUBJECTS' | 'FACULTY' | 'ROOMS'>('SUBJECTS');

  // Subject form state
  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [batch, setBatch] = useState('CSE-A');
  const [batchSize, setBatchSize] = useState(40);
  const [credits, setCredits] = useState(3);
  const [lectureHours, setLectureHours] = useState(3);
  const [labBlockSize, setLabBlockSize] = useState(0);
  const [labBlocksPerWeek, setLabBlocksPerWeek] = useState(0);
  const [equipmentStr, setEquipmentStr] = useState('Projector');
  const [facultyId, setFacultyId] = useState(facultyList[0]?.id ?? '');
  const [editingSubjectId, setEditingSubjectId] = useState<string | null>(null);

  // Faculty form state
  const [facName, setFacName] = useState('');
  const [facDept, setFacDept] = useState('CSE');
  const [facMaxHours, setFacMaxHours] = useState(12);
  const [facPref, setFacPref] = useState<'ANY' | 'MORNING' | 'AFTERNOON'>('ANY');
  const [editingFacultyId, setEditingFacultyId] = useState<string | null>(null);
  const [facAvailability, setFacAvailability] = useState<Faculty['availability']>(() =>
    Object.fromEntries(DAYS_OF_WEEK.map((day) => [day, [1, 2, 3, 4, 5, 6]])) as Faculty['availability']
  );

  // Classroom form state
  const [roomName, setRoomName] = useState('');
  const [building, setBuilding] = useState('Main Block');
  const [capacity, setCapacity] = useState(50);
  const [isLab, setIsLab] = useState(false);
  const [roomEqStr, setRoomEqStr] = useState('Projector');
  const [editingRoomId, setEditingRoomId] = useState<string | null>(null);

  const resetSubjectForm = () => {
    setEditingSubjectId(null);
    setCode('');
    setName('');
    setBatch('CSE-A');
    setBatchSize(40);
    setCredits(3);
    setLectureHours(3);
    setLabBlockSize(0);
    setLabBlocksPerWeek(0);
    setEquipmentStr('Projector');
    setFacultyId(facultyList[0]?.id ?? '');
  };

  const resetFacultyForm = () => {
    setEditingFacultyId(null);
    setFacName('');
    setFacDept('CSE');
    setFacMaxHours(12);
    setFacPref('ANY');
    setFacAvailability(Object.fromEntries(DAYS_OF_WEEK.map((day) => [day, [1, 2, 3, 4, 5, 6]])) as Faculty['availability']);
  };

  const resetRoomForm = () => {
    setEditingRoomId(null);
    setRoomName('');
    setBuilding('Main Block');
    setCapacity(50);
    setIsLab(false);
    setRoomEqStr('Projector');
  };

  const handleCreateSubject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !name.trim()) return;
    const chosenFacId = facultyId || facultyList[0]?.id;
    if (!chosenFacId) return;
    const subject: Subject = {
      id: editingSubjectId ?? `sub-${Date.now()}`,
      code: code.trim().toUpperCase(),
      name: name.trim(),
      batch: batch.trim() || 'CSE-A',
      batchSize: Math.max(1, Number(batchSize) || 40),
      credits: Math.max(1, Number(credits) || 3),
      lectureHoursPerWeek: Math.max(0, Number(lectureHours) || 0),
      labBlockSize: Math.max(0, Number(labBlockSize) || 0),
      labBlocksPerWeek: Math.max(0, Number(labBlocksPerWeek) || 0),
      requiredEquipment: equipmentStr
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
      facultyId: chosenFacId,
    };
    if (editingSubjectId) onUpdateSubject(editingSubjectId, subject);
    else onAddSubject(subject);
    resetSubjectForm();
  };

  const handleCreateFaculty = (e: React.FormEvent) => {
    e.preventDefault();
    if (!facName.trim()) return;
    const faculty: Faculty = {
      id: editingFacultyId ?? `fac-${Date.now()}`,
      name: facName.trim(),
      department: facDept.trim() || 'CSE',
      maxWeeklyHours: Math.max(1, Number(facMaxHours) || 12),
      preferredTimeOfDay: facPref,
      availability: facAvailability,
    };
    if (editingFacultyId) onUpdateFaculty(editingFacultyId, faculty);
    else onAddFaculty(faculty);
    resetFacultyForm();
  };

  const toggleFacultySlot = (day: DayOfWeek, period: number) => {
    setFacAvailability((current) => {
      const available = current[day] ?? [1, 2, 3, 4, 5, 6];
      const next = available.includes(period)
        ? available.filter((item) => item !== period)
        : [...available, period].sort((a, b) => a - b);
      return { ...current, [day]: next };
    });
  };

  const handleCreateClassroom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomName.trim()) return;
    const room: Classroom = {
      id: editingRoomId ?? `room-${Date.now()}`,
      name: roomName.trim(),
      building: building.trim() || 'Main Block',
      capacity: Math.max(5, Number(capacity) || 40),
      isLab,
      equipment: roomEqStr
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
    };
    if (editingRoomId) onUpdateClassroom(editingRoomId, room);
    else onAddClassroom(room);
    resetRoomForm();
  };

  const editSubject = (subject: Subject) => {
    setEditingSubjectId(subject.id);
    setCode(subject.code);
    setName(subject.name);
    setBatch(subject.batch);
    setBatchSize(subject.batchSize);
    setCredits(subject.credits);
    setLectureHours(subject.lectureHoursPerWeek);
    setLabBlockSize(subject.labBlockSize);
    setLabBlocksPerWeek(subject.labBlocksPerWeek);
    setEquipmentStr(subject.requiredEquipment.join(', '));
    setFacultyId(subject.facultyId);
    setTab('SUBJECTS');
  };

  const editFaculty = (faculty: Faculty) => {
    setEditingFacultyId(faculty.id);
    setFacName(faculty.name);
    setFacDept(faculty.department);
    setFacMaxHours(faculty.maxWeeklyHours);
    setFacPref(faculty.preferredTimeOfDay ?? 'ANY');
    setFacAvailability(Object.fromEntries(
      DAYS_OF_WEEK.map((day) => [day, faculty.availability[day] ?? [1, 2, 3, 4, 5, 6]])
    ) as Faculty['availability']);
    setTab('FACULTY');
  };

  const editClassroom = (room: Classroom) => {
    setEditingRoomId(room.id);
    setRoomName(room.name);
    setBuilding(room.building);
    setCapacity(room.capacity);
    setIsLab(room.isLab);
    setRoomEqStr(room.equipment.join(', '));
    setTab('ROOMS');
  };

  const facNameMap = new Map(facultyList.map((f) => [f.id, f.name]));

  return (
    <div className="no-print bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <h3 className="text-sm font-semibold text-slate-900">Academic Resource Manager</h3>
        <div className="flex rounded-lg bg-slate-100 p-0.5 text-xs font-medium">
          <button
            type="button"
            onClick={() => setTab('SUBJECTS')}
            className={`px-3 py-1 rounded-md flex items-center gap-1.5 ${
              tab === 'SUBJECTS' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> Subjects ({subjects.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('FACULTY')}
            className={`px-3 py-1 rounded-md flex items-center gap-1.5 ${
              tab === 'FACULTY' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600'
            }`}
          >
            <Users className="w-3.5 h-3.5" /> Faculty ({facultyList.length})
          </button>
          <button
            type="button"
            onClick={() => setTab('ROOMS')}
            className={`px-3 py-1 rounded-md flex items-center gap-1.5 ${
              tab === 'ROOMS' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" /> Rooms ({classrooms.length})
          </button>
        </div>
      </div>

      {tab === 'SUBJECTS' && (
        <div className="space-y-4">
          <form onSubmit={handleCreateSubject} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 text-xs">
            <input
              type="text"
              placeholder="Code (e.g. CS401)"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300"
              required
            />
            <input
              type="text"
              placeholder="Subject Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300"
              required
            />
            <input
              type="text"
              placeholder="Batch (e.g. CSE-A)"
              value={batch}
              onChange={(e) => setBatch(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300"
            />
            <select
              value={facultyId || facultyList[0]?.id || ''}
              onChange={(e) => setFacultyId(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300 bg-white"
            >
              {facultyList.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name} (Max {f.maxWeeklyHours}h)
                </option>
              ))}
            </select>
            <button
              type="submit"
              disabled={!facultyList.length && !editingSubjectId}
              className="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> {editingSubjectId ? 'Save Subject' : 'Add Subject'}
            </button>
            {editingSubjectId && <button type="button" onClick={resetSubjectForm} className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600">Cancel</button>}

            <label className="flex flex-col gap-1 text-[11px] text-slate-600">
              Batch Size
              <input
                type="number"
                min={1}
                value={batchSize}
                onChange={(e) => setBatchSize(Number(e.target.value))}
                className="px-2 py-1.5 rounded border border-slate-300 text-slate-900"
              />
            </label>
            <label className="flex flex-col gap-1 text-[11px] text-slate-600">
              Lecture Hrs/Wk
              <input
                type="number"
                min={0}
                max={8}
                value={lectureHours}
                onChange={(e) => setLectureHours(Number(e.target.value))}
                className="px-2 py-1.5 rounded border border-slate-300 text-slate-900"
              />
            </label>
            <label className="flex flex-col gap-1 text-[11px] text-slate-600">
              Lab Block Hrs (e.g. 3)
              <input
                type="number"
                min={0}
                max={6}
                value={labBlockSize}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setLabBlockSize(val);
                  if (val > 0 && labBlocksPerWeek === 0) setLabBlocksPerWeek(1);
                  if (val === 0) setLabBlocksPerWeek(0);
                }}
                className="px-2 py-1.5 rounded border border-slate-300 text-slate-900"
              />
            </label>
            <label className="flex flex-col gap-1 text-[11px] text-slate-600">
              Lab Blocks/Wk
              <input
                type="number"
                min={0}
                max={3}
                value={labBlocksPerWeek}
                onChange={(e) => setLabBlocksPerWeek(Number(e.target.value))}
                className="px-2 py-1.5 rounded border border-slate-300 text-slate-900"
              />
            </label>
            <label className="flex flex-col gap-1 text-[11px] text-slate-600">
              Required Equipment
              <input
                type="text"
                value={equipmentStr}
                onChange={(e) => setEquipmentStr(e.target.value)}
                placeholder="Projector, Linux Workstations"
                className="px-2 py-1.5 rounded border border-slate-300 text-slate-900"
              />
            </label>
          </form>

          <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto text-xs">
            {subjects.map((s) => (
              <div key={s.id} className="py-2 flex items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-slate-900">{s.code}</span>{' '}
                  <span className="text-slate-700">— {s.name}</span>
                  <span className="ml-2 text-slate-500">
                    [{s.batch} • {s.batchSize} cap • {s.lectureHoursPerWeek}L
                    {s.labBlocksPerWeek > 0 ? ` + ${s.labBlocksPerWeek}×${s.labBlockSize}h Lab` : ''} •{' '}
                    {facNameMap.get(s.facultyId) ?? s.facultyId}]
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button type="button" onClick={() => editSubject(s)} className="text-blue-700 hover:text-blue-900 font-semibold" title="Edit subject">Edit</button>
                  <button type="button" onClick={() => onDeleteSubject(s.id)} className="p-1 text-slate-400 hover:text-red-600" title="Remove subject">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'FACULTY' && (
        <div className="space-y-4">
          <form onSubmit={handleCreateFaculty} className="grid grid-cols-1 sm:grid-cols-5 gap-2.5 text-xs">
            <input
              type="text"
              placeholder="Faculty Name (e.g. Dr. Patel)"
              value={facName}
              onChange={(e) => setFacName(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300"
              required
            />
            <input
              type="text"
              placeholder="Department"
              value={facDept}
              onChange={(e) => setFacDept(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300"
            />
            <input
              type="number"
              min={1}
              max={30}
              value={facMaxHours}
              onChange={(e) => setFacMaxHours(Number(e.target.value))}
              placeholder="Max Weekly Hours"
              className="px-2.5 py-2 rounded-lg border border-slate-300"
            />
            <select
              value={facPref}
              onChange={(e) => setFacPref(e.target.value as 'ANY' | 'MORNING' | 'AFTERNOON')}
              className="px-2.5 py-2 rounded-lg border border-slate-300 bg-white"
            >
              <option value="ANY">Preference: Any Slot</option>
              <option value="MORNING">Preference: Morning</option>
              <option value="AFTERNOON">Preference: Afternoon</option>
            </select>
            <button
              type="submit"
              className="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> {editingFacultyId ? 'Save Faculty' : 'Add Faculty'}
            </button>
            {editingFacultyId && <button type="button" onClick={resetFacultyForm} className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600">Cancel</button>}
            <div className="sm:col-span-5 space-y-1.5 rounded-lg border border-slate-200 bg-slate-50 p-2.5">
              <div className="font-semibold text-slate-700">Available teaching periods</div>
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                {DAYS_OF_WEEK.map((day) => (
                  <div key={day} className="rounded-md bg-white border border-slate-200 p-2">
                    <div className="text-[10px] font-semibold text-slate-600 mb-1">{day}</div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5, 6].map((period) => {
                        const selected = (facAvailability[day] ?? []).includes(period);
                        return (
                          <button
                            key={period}
                            type="button"
                            aria-pressed={selected}
                            aria-label={`${day}, period ${period} ${selected ? 'available' : 'unavailable'}`}
                            onClick={() => toggleFacultySlot(day, period)}
                            className={`w-6 h-6 rounded text-[10px] font-semibold ${selected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'}`}
                          >
                            {period}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-[10px] text-slate-500">Blue periods are available to schedule.</p>
            </div>
          </form>

          <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto text-xs">
            {facultyList.map((f) => (
              <div key={f.id} className="py-2 flex items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-slate-900">{f.name}</span>{' '}
                  <span className="text-slate-500">
                    ({f.department} • Max {f.maxWeeklyHours}h/wk • Pref: {f.preferredTimeOfDay ?? 'ANY'})
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button type="button" onClick={() => editFaculty(f)} className="text-blue-700 hover:text-blue-900 font-semibold" title="Edit faculty">Edit</button>
                  <button type="button" onClick={() => onDeleteFaculty(f.id)} className="p-1 text-slate-400 hover:text-red-600" title="Remove faculty">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'ROOMS' && (
        <div className="space-y-4">
          <form onSubmit={handleCreateClassroom} className="grid grid-cols-1 sm:grid-cols-6 gap-2.5 text-xs">
            <input
              type="text"
              placeholder="Room / Lab Name"
              value={roomName}
              onChange={(e) => setRoomName(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300"
              required
            />
            <input
              type="text"
              placeholder="Building"
              value={building}
              onChange={(e) => setBuilding(e.target.value)}
              className="px-2.5 py-2 rounded-lg border border-slate-300"
            />
            <input
              type="number"
              min={5}
              max={500}
              value={capacity}
              onChange={(e) => setCapacity(Number(e.target.value))}
              placeholder="Capacity"
              className="px-2.5 py-2 rounded-lg border border-slate-300"
            />
            <input
              type="text"
              value={roomEqStr}
              onChange={(e) => setRoomEqStr(e.target.value)}
              placeholder="Equipment (comma sep)"
              className="px-2.5 py-2 rounded-lg border border-slate-300"
            />
            <label className="flex items-center gap-2 px-2 py-1.5 rounded-lg border border-slate-200 bg-slate-50">
              <input
                type="checkbox"
                checked={isLab}
                onChange={(e) => setIsLab(e.target.checked)}
              />
              <span>Lab Room</span>
            </label>
            <button
              type="submit"
              className="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> {editingRoomId ? 'Save Room' : 'Add Room'}
            </button>
            {editingRoomId && <button type="button" onClick={resetRoomForm} className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600">Cancel</button>}
          </form>

          <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto text-xs">
            {classrooms.map((r) => (
              <div key={r.id} className="py-2 flex items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-slate-900">{r.name}</span>{' '}
                  <span className="text-slate-500">
                    ({r.building} • Cap {r.capacity} • {r.isLab ? 'Lab' : 'Lecture'} •{' '}
                    {r.equipment.join(', ') || 'Standard'})
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button type="button" onClick={() => editClassroom(r)} className="text-blue-700 hover:text-blue-900 font-semibold" title="Edit classroom">Edit</button>
                  <button type="button" onClick={() => onDeleteClassroom(r.id)} className="p-1 text-slate-400 hover:text-red-600" title="Remove classroom">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
