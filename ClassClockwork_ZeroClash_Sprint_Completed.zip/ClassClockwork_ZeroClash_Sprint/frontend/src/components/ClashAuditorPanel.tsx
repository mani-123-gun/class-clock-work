import React from 'react';
import { AlertCircle, CheckCircle2, ShieldAlert, Sparkles } from 'lucide-react';
import { ClashViolation, SolverMetrics, UnallocatedItem } from '../../../shared/types';

interface ClashAuditorPanelProps {
  clashes: ClashViolation[];
  unallocated: UnallocatedItem[];
  metrics: SolverMetrics | null;
  statusBanner: string | null;
}

export const ClashAuditorPanel: React.FC<ClashAuditorPanelProps> = ({
  clashes,
  unallocated,
  metrics,
  statusBanner,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-4">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-rose-600" />
          <h3 className="text-sm font-semibold text-slate-900">
            Real-Time Clash Detection Auditor
          </h3>
        </div>
        <span
          className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${
            clashes.length === 0
              ? 'bg-emerald-100 text-emerald-800'
              : 'bg-red-100 text-red-800'
          }`}
        >
          {clashes.length === 0 ? '0 Clashes' : `${clashes.length} Active Clash${clashes.length > 1 ? 'es' : ''}`}
        </span>
      </div>

      {statusBanner && (
        <div className="px-3 py-2 rounded-lg bg-slate-100 text-slate-800 text-xs font-medium flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          <span>{statusBanner}</span>
        </div>
      )}

      {metrics && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-slate-500">Solve Time</div>
            <div className="font-bold text-slate-900 mt-0.5">{metrics.elapsedMs} ms</div>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-slate-500">Backtracks</div>
            <div className="font-bold text-slate-900 mt-0.5">{metrics.backtracks}</div>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-slate-500">Faculty Gini</div>
            <div className="font-bold text-slate-900 mt-0.5">{metrics.facultyGiniCoefficient}</div>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-slate-500">Lunch Free</div>
            <div className="font-bold text-slate-900 mt-0.5">{metrics.lunchComplianceRate}%</div>
          </div>
        </div>
      )}

      {clashes.length === 0 ? (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>All hard constraints satisfied — zero faculty, classroom, or batch conflicts detected.</span>
        </div>
      ) : (
        <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
          {clashes.map((clash) => (
            <div
              key={clash.id}
              className="p-2.5 rounded-lg bg-red-50 border border-red-300 text-red-900 text-xs flex items-start gap-2"
            >
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div className="font-medium leading-snug">{clash.message}</div>
            </div>
          ))}
        </div>
      )}

      {unallocated.length > 0 && (
        <div className="space-y-1.5 pt-2 border-t border-slate-100">
          <div className="text-xs font-semibold text-amber-800">
            Unallocated Items ({unallocated.length})
          </div>
          {unallocated.map((item, idx) => (
            <div
              key={`${item.subjectId}-${idx}`}
              className="p-2 rounded bg-amber-50 border border-amber-200 text-amber-950 text-xs"
            >
              <span className="font-semibold">
                {item.subjectCode} ({item.batch} • {item.kind} {item.duration}h):
              </span>{' '}
              {item.reason}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
