import React, { useState } from 'react';
import { AlertTriangle, GripVertical, Lock, Unlock, Layers, Clock } from 'lucide-react';
import {
  Classroom,
  ClashViolation,
  DAYS_OF_WEEK,
  DayOfWeek,
  Faculty,
  PERIODS_PER_DAY,
  Subject,
  TimetableAllocation,
} from '../../../shared/types';
import { getPeriodLabel } from '../utils/scheduleUtils';

interface TimetableGridProps {
  viewMode: 'BATCH' | 'FACULTY';
  selectedBatch: string;
  selectedFacultyId: string;
  lunchPeriod: number;
  allocations: TimetableAllocation[];
  subjects: Subject[];
  facultyList: Faculty[];
  classrooms: Classroom[];
  clashes: ClashViolation[];
  onMoveAllocation: (allocationId: string, targetDay: DayOfWeek, targetPeriod: number) => void;
  onToggleLock: (allocationId: string) => void;
}

export const TimetableGrid: React.FC<TimetableGridProps> = ({
  viewMode,
  selectedBatch,
  selectedFacultyId,
  lunchPeriod,
  allocations,
  subjects,
  facultyList,
  classrooms,
  clashes,
  onMoveAllocation,
  onToggleLock,
}) => {
  const [draggedAllocId, setDraggedAllocId] = useState<string | null>(null);
  const [dragOverCell, setDragOverCell] = useState<string | null>(null);

  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const facultyMap = new Map(facultyList.map((f) => [f.id, f]));
  const roomMap = new Map(classrooms.map((c) => [c.id, c]));

  const filteredAllocations = allocations.filter((a) =>
    viewMode === 'BATCH' ? a.batch === selectedBatch : a.facultyId === selectedFacultyId
  );

  // Map allocation IDs that participate in a clash
  const clashingAllocIds = new Set<string>();
  const clashMessagesByAllocId = new Map<string, string[]>();
  for (const c of clashes) {
    for (const id of c.allocationIds) {
      clashingAllocIds.add(id);
      const arr = clashMessagesByAllocId.get(id) ?? [];
      arr.push(c.message);
      clashMessagesByAllocId.set(id, arr);
    }
  }

  const periods = Array.from({ length: PERIODS_PER_DAY }, (_, idx) => idx + 1);

  const handleDragStart = (e: React.DragEvent, allocId: string) => {
    setDraggedAllocId(allocId);
    e.dataTransfer.setData('text/plain', allocId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, day: DayOfWeek, period: number) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    const cellKey = `${day}-${period}`;
    if (dragOverCell !== cellKey) {
      setDragOverCell(cellKey);
    }
  };

  const handleDrop = (e: React.DragEvent, day: DayOfWeek, period: number) => {
    e.preventDefault();
    const idFromData = e.dataTransfer.getData('text/plain');
    const allocId = idFromData || draggedAllocId;
    setDragOverCell(null);
    setDraggedAllocId(null);
    if (allocId) {
      onMoveAllocation(allocId, day, period);
    }
  };

  return (
    <div className="print-grid bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 bg-slate-50/70">
        <div>
          <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-600" />
            {viewMode === 'BATCH'
              ? `Batch Timetable — ${selectedBatch}`
              : `Faculty Schedule — ${facultyMap.get(selectedFacultyId)?.name ?? selectedFacultyId}`}
          </h2>
          <p className="text-xs text-slate-500">
            5-Day × 6-Period Weekly Matrix • Drag &amp; drop blocks to test or adjust slots with real-time clash validation
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200 font-medium">
            Lecture (1P)
          </span>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200 font-medium">
            <Layers className="w-3 h-3" /> Lab Block (Multi-P)
          </span>
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-50 text-red-700 border border-red-300 font-medium">
            <AlertTriangle className="w-3 h-3" /> Rule Clash
          </span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse min-w-[820px] text-left">
          <thead>
            <tr className="bg-slate-100/90 border-b border-slate-200 text-xs font-semibold uppercase tracking-wider text-slate-600">
              <th className="p-3 w-28 border-r border-slate-200">Day</th>
              {periods.map((p) => (
                <th key={p} className="p-3 border-r border-slate-200 last:border-r-0">
                  <div className="flex items-center justify-between">
                    <span>{getPeriodLabel(p)}</span>
                    {p === lunchPeriod && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold">
                        Lunch Window
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {DAYS_OF_WEEK.map((day) => {
              // Build period map for this day
              const cellAllocations = new Map<number, TimetableAllocation>();
              const coveredByMultiPeriod = new Set<number>();

              for (const alloc of filteredAllocations) {
                if (alloc.day !== day) continue;
                cellAllocations.set(alloc.startPeriod, alloc);
                for (let p = alloc.startPeriod + 1; p < alloc.startPeriod + alloc.duration; p++) {
                  coveredByMultiPeriod.add(p);
                }
              }

              return (
                <tr key={day} className="border-b border-slate-200 last:border-b-0 align-top">
                  <td className="p-3 font-semibold text-sm text-slate-800 bg-slate-50/60 border-r border-slate-200">
                    {day}
                  </td>
                  {periods.map((period) => {
                    if (coveredByMultiPeriod.has(period)) {
                      return null;
                    }

                    const alloc = cellAllocations.get(period);
                    const colSpan = alloc ? Math.min(alloc.duration, PERIODS_PER_DAY - period + 1) : 1;
                    const cellKey = `${day}-${period}`;
                    const isOver = dragOverCell === cellKey;

                    const subj = alloc ? subjectMap.get(alloc.subjectId) : undefined;
                    const fac = alloc ? facultyMap.get(alloc.facultyId) : undefined;
                    const room = alloc ? roomMap.get(alloc.roomId) : undefined;
                    const hasClash = alloc ? clashingAllocIds.has(alloc.id) : false;
                    const allocClashes = alloc ? clashMessagesByAllocId.get(alloc.id) ?? [] : [];

                    let cardStyle =
                      'bg-blue-50/90 border-blue-200 text-blue-950 hover:border-blue-300';
                    if (alloc?.kind === 'LAB') {
                      cardStyle =
                        'bg-purple-50/90 border-purple-300 text-purple-950 hover:border-purple-400';
                    }
                    if (hasClash) {
                      cardStyle =
                        'bg-red-100 border-red-500 text-red-950 ring-2 ring-red-400/60';
                    }

                    return (
                      <td
                        key={period}
                        colSpan={colSpan}
                        onDragOver={(e) => handleDragOver(e, day, period)}
                        onDragLeave={() => setDragOverCell(null)}
                        onDrop={(e) => handleDrop(e, day, period)}
                        className={`p-2 border-r border-slate-200 last:border-r-0 min-h-[104px] transition-colors ${
                          isOver ? 'bg-blue-100/80 ring-2 ring-inset ring-blue-400' : ''
                        }`}
                      >
                        {alloc ? (
                          <div
                            draggable
                            onDragStart={(e) => handleDragStart(e, alloc.id)}
                            title={
                              hasClash
                                ? allocClashes.join(' | ')
                                : 'Drag block to another day/period to test or reschedule'
                            }
                            className={`rounded-lg border p-2.5 h-full min-h-[86px] flex flex-col justify-between cursor-grab active:cursor-grabbing transition-all ${cardStyle}`}
                          >
                            <div>
                              <div className="flex items-start justify-between gap-1">
                                <div className="flex items-center gap-1 min-w-0">
                                  <GripVertical className="w-3.5 h-3.5 shrink-0 opacity-60" />
                                  <span className="font-bold text-xs tracking-tight truncate">
                                    {subj?.code ?? alloc.subjectId}
                                  </span>
                                  {alloc.duration > 1 && (
                                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-purple-600 text-white font-semibold shrink-0">
                                      {alloc.duration}h LAB
                                    </span>
                                  )}
                                </div>
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onToggleLock(alloc.id);
                                  }}
                                  className="no-print p-0.5 rounded hover:bg-black/10 text-slate-600"
                                  title={alloc.isLocked ? 'Unlock slot' : 'Lock slot during regeneration'}
                                >
                                  {alloc.isLocked ? (
                                    <Lock className="w-3.5 h-3.5 text-amber-700" />
                                  ) : (
                                    <Unlock className="w-3.5 h-3.5 opacity-50" />
                                  )}
                                </button>
                              </div>
                              <div className="text-xs font-medium mt-0.5 line-clamp-1">
                                {subj?.name ?? 'Subject'}
                              </div>
                            </div>

                            <div className="mt-2 pt-1.5 border-t border-black/10 flex flex-wrap items-center justify-between gap-1 text-[11px]">
                              <span className="font-semibold truncate">
                                {fac?.name ?? alloc.facultyId}
                              </span>
                              <span className="px-1.5 py-0.5 rounded bg-white/80 border border-black/10 font-medium">
                                {room?.name ?? alloc.roomId}
                              </span>
                            </div>

                            {hasClash && (
                              <div className="mt-1.5 px-1.5 py-1 rounded bg-red-600 text-white text-[10px] font-semibold leading-tight">
                                {allocClashes[0]}
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="h-[86px] rounded-lg border border-dashed border-slate-200 flex items-center justify-center text-[11px] text-slate-400 select-none">
                            {period === lunchPeriod ? 'Break / Open' : 'Drop slot'}
                          </div>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
