import React, { useEffect, useMemo, useState } from 'react';
import {
  Calendar as CalendarIcon,
  Database,
  Play,
  Printer,
  RotateCcw,
  Users,
  GraduationCap,
} from 'lucide-react';
import {
  Classroom,
  ClashViolation,
  DayOfWeek,
  Faculty,
  PERIODS_PER_DAY,
  SolverMetrics,
  Subject,
  TimetableAllocation,
  TimetableDataset,
  UnallocatedItem,
} from '../../shared/types';
import { detectClashes } from '../../backend/src/solver/clashAuditor';
import { DEMO_6_SUBJECT_DATASET, SAMPLE_CS_SEMESTER_DATASET } from '../../backend/src/data/sampleData';
import {
  fetchActiveDataset,
  generateScheduleOnServer,
  loadPresetDataset,
  saveDatasetToServer,
} from './services/apiClient';
import { TimetableGrid } from './components/TimetableGrid';
import { ClashAuditorPanel } from './components/ClashAuditorPanel';
import { ResourceManager } from './components/ResourceManager';
import {
  buildIcsCalendar,
  calculateFacultyGini,
  downloadTextFile,
} from './utils/scheduleUtils';

const LOCAL_STORAGE_KEY = 'classclockwork_active_dataset_v1';

function copyDataset(dataset: TimetableDataset): TimetableDataset {
  return JSON.parse(JSON.stringify(dataset)) as TimetableDataset;
}

function hasDatasetShape(value: unknown): value is TimetableDataset {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Partial<TimetableDataset>;
  const isRecord = (entry: unknown): entry is Record<string, unknown> => Boolean(entry) && typeof entry === 'object';
  return typeof candidate.id === 'string' &&
    typeof candidate.name === 'string' &&
    Array.isArray(candidate.subjects) &&
    Array.isArray(candidate.faculty) &&
    Array.isArray(candidate.classrooms) &&
    Array.isArray(candidate.allocations) &&
    candidate.subjects.every((entry) => isRecord(entry) && typeof entry.id === 'string' && typeof entry.name === 'string' && typeof entry.batch === 'string' && Array.isArray(entry.requiredEquipment)) &&
    candidate.faculty.every((entry) => isRecord(entry) && typeof entry.id === 'string' && typeof entry.name === 'string' && isRecord(entry.availability)) &&
    candidate.classrooms.every((entry) => isRecord(entry) && typeof entry.id === 'string' && typeof entry.name === 'string' && Array.isArray(entry.equipment)) &&
    candidate.allocations.every((entry) => isRecord(entry) && typeof entry.id === 'string' && typeof entry.subjectId === 'string' && typeof entry.facultyId === 'string' && typeof entry.roomId === 'string');
}

function cacheDataset(dataset: TimetableDataset): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(dataset));
  } catch {
    // The app remains usable if browser storage is unavailable or full.
  }
}

export default function App() {
  const [dataset, setDataset] = useState<TimetableDataset | null>(null);
  const [viewMode, setViewMode] = useState<'BATCH' | 'FACULTY'>('BATCH');
  const [selectedBatch, setSelectedBatch] = useState<string>('CSE-A');
  const [selectedFacultyId, setSelectedFacultyId] = useState<string>('');
  const [lunchPeriod, setLunchPeriod] = useState<number>(4);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [metrics, setMetrics] = useState<SolverMetrics | null>(null);
  const [unallocated, setUnallocated] = useState<UnallocatedItem[]>([]);
  const [statusBanner, setStatusBanner] = useState<string | null>(null);

  // Hydrate from localStorage first, then sync with backend
  useEffect(() => {
    let cachedDataset: TimetableDataset | null = null;
    let cachedRaw: string | null = null;
    try {
      cachedRaw = localStorage.getItem(LOCAL_STORAGE_KEY);
    } catch {
      // Fall back to the bundled demo if browser storage is disabled.
    }
    if (cachedRaw) {
      try {
        const parsed: unknown = JSON.parse(cachedRaw);
        if (!hasDatasetShape(parsed)) throw new Error('Cached timetable has an invalid shape.');
        cachedDataset = parsed;
        setDataset(cachedDataset);
        if (cachedDataset.subjects[0]?.batch) setSelectedBatch(cachedDataset.subjects[0].batch);
        if (cachedDataset.faculty[0]?.id) setSelectedFacultyId(cachedDataset.faculty[0].id);
      } catch {
        // Ignore malformed localStorage
      }
    }

    fetchActiveDataset()
      .then((serverDs) => {
        setDataset(serverDs);
        cacheDataset(serverDs);
        if (serverDs.subjects[0]?.batch) {
          setSelectedBatch((prev) =>
            serverDs.subjects.some((s) => s.batch === prev) ? prev : serverDs.subjects[0].batch
          );
        }
        if (serverDs.faculty[0]?.id) {
          setSelectedFacultyId((prev) =>
            serverDs.faculty.some((f) => f.id === prev) ? prev : serverDs.faculty[0].id
          );
        }
      })
      .catch(() => {
        const localDataset = cachedDataset ?? copyDataset(DEMO_6_SUBJECT_DATASET);
        setDataset(localDataset);
        cacheDataset(localDataset);
        if (localDataset.subjects[0]?.batch) setSelectedBatch(localDataset.subjects[0].batch);
        if (localDataset.faculty[0]?.id) setSelectedFacultyId(localDataset.faculty[0].id);
        setStatusBanner('Using a saved local timetable. Start the backend to generate schedules and sync data.');
      });
  }, []);

  const persistDataset = (next: TimetableDataset) => {
    setDataset(next);
    cacheDataset(next);
    saveDatasetToServer(next).catch(() => {
      // Offline/local fallback still intact
    });
  };

  const clashes: ClashViolation[] = useMemo(() => {
    if (!dataset) return [];
    return detectClashes(
      dataset.allocations,
      dataset.subjects,
      dataset.faculty,
      dataset.classrooms
    );
  }, [dataset]);

  const batches = useMemo(() => {
    if (!dataset) return ['CSE-A'];
    const set = new Set(dataset.subjects.map((s) => s.batch));
    return Array.from(set);
  }, [dataset]);

  useEffect(() => {
    if (batches.length > 0 && !batches.includes(selectedBatch)) {
      setSelectedBatch(batches[0]);
    }
  }, [batches, selectedBatch]);

  useEffect(() => {
    if (dataset && dataset.faculty.length > 0 && !dataset.faculty.some((f) => f.id === selectedFacultyId)) {
      setSelectedFacultyId(dataset.faculty[0].id);
    }
  }, [dataset, selectedFacultyId]);

  const handleGenerate = async () => {
    if (!dataset) return;
    setIsGenerating(true);
    setStatusBanner('Running CSP solver with MRV ordering and lab macro-slot allocation...');
    try {
      const { result, dataset: updatedDs } = await generateScheduleOnServer({
        subjects: dataset.subjects,
        faculty: dataset.faculty,
        classrooms: dataset.classrooms,
        preserveLocked: true,
        lockedAllocations: dataset.allocations.filter((allocation) => allocation.isLocked),
        lunchPeriod,
      });
      setDataset(updatedDs);
      cacheDataset(updatedDs);
      setMetrics(result.metrics);
      setUnallocated(result.unallocated);
      setStatusBanner(result.message);
    } catch (err) {
      setStatusBanner(err instanceof Error ? err.message : 'Generation failed.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleLoadPreset = async (preset: 'demo6' | 'cs8') => {
    setStatusBanner(`Loading ${preset === 'demo6' ? '6-subject demo' : '8-subject CS semester'} preset...`);
    try {
      const loaded = await loadPresetDataset(preset);
      setDataset(loaded);
      cacheDataset(loaded);
      setUnallocated([]);
      setMetrics(null);
      if (loaded.subjects[0]?.batch) setSelectedBatch(loaded.subjects[0].batch);
      if (loaded.faculty[0]?.id) setSelectedFacultyId(loaded.faculty[0].id);
      setStatusBanner(`Loaded "${loaded.name}". Click Generate Timetable to schedule.`);
    } catch {
      const localPreset = copyDataset(preset === 'demo6' ? DEMO_6_SUBJECT_DATASET : SAMPLE_CS_SEMESTER_DATASET);
      setDataset(localPreset);
      cacheDataset(localPreset);
      setUnallocated([]);
      setMetrics(null);
      if (localPreset.subjects[0]?.batch) setSelectedBatch(localPreset.subjects[0].batch);
      if (localPreset.faculty[0]?.id) setSelectedFacultyId(localPreset.faculty[0].id);
      setStatusBanner(`Loaded "${localPreset.name}" locally. Start the backend to generate schedules.`);
    }
  };

  const handleMoveAllocation = (
    allocationId: string,
    targetDay: DayOfWeek,
    targetPeriod: number
  ) => {
    if (!dataset) return;
    const targetAlloc = dataset.allocations.find((a) => a.id === allocationId);
    if (!targetAlloc) return;

    const clampedStart = Math.max(
      1,
      Math.min(PERIODS_PER_DAY - targetAlloc.duration + 1, targetPeriod)
    );

    const nextAllocations: TimetableAllocation[] = dataset.allocations.map((a) =>
      a.id === allocationId
        ? { ...a, day: targetDay, startPeriod: clampedStart }
        : a
    );

    const nextDataset: TimetableDataset = {
      ...dataset,
      allocations: nextAllocations,
      updatedAt: new Date().toISOString(),
    };
    persistDataset(nextDataset);

    const updatedClashes = detectClashes(
      nextAllocations,
      dataset.subjects,
      dataset.faculty,
      dataset.classrooms
    );
    const relevantClashes = updatedClashes.filter((c) => c.allocationIds.includes(allocationId));
    if (relevantClashes.length > 0) {
      setStatusBanner(relevantClashes[0].message);
    } else {
      setStatusBanner(
        `Moved allocation to ${targetDay} Period ${clampedStart} with no conflicts.`
      );
    }
  };

  const handleToggleLock = (allocationId: string) => {
    if (!dataset) return;
    const nextAllocations = dataset.allocations.map((a) =>
      a.id === allocationId ? { ...a, isLocked: !a.isLocked } : a
    );
    persistDataset({ ...dataset, allocations: nextAllocations });
  };

  const handleExportIcs = () => {
    if (!dataset) return;
    const scoped =
      viewMode === 'BATCH'
        ? dataset.allocations.filter((a) => a.batch === selectedBatch)
        : dataset.allocations.filter((a) => a.facultyId === selectedFacultyId);
    const label =
      viewMode === 'BATCH'
        ? `Batch_${selectedBatch}`
        : `Faculty_${dataset.faculty.find((f) => f.id === selectedFacultyId)?.name ?? selectedFacultyId}`;
    const icsContent = buildIcsCalendar(
      scoped,
      dataset.subjects,
      dataset.faculty,
      dataset.classrooms,
      `ClassClockwork - ${label}`
    );
    downloadTextFile(`ClassClockwork_${label}.ics`, icsContent);
    setStatusBanner(`Exported iCalendar (.ics) file for ${label}.`);
  };

  if (!dataset) {
    return (
      <div className="min-h-screen flex items-center justify-center text-slate-600 text-sm">
        Initializing ClassClockwork...
      </div>
    );
  }

  const gini = calculateFacultyGini(dataset.allocations, dataset.faculty);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top Bar */}
      <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-blue-600 text-white font-bold text-xs">
                CC
              </span>
              <h1 className="text-lg font-bold tracking-tight text-slate-900">
                ClassClockwork <span className="text-blue-600">ZeroClash</span>
              </h1>
            </div>
            <p className="text-xs text-slate-500">
              Constraint Satisfaction Timetable Engine • Gini Load: <strong className="text-slate-700">{gini}</strong>
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => handleLoadPreset('demo6')}
              className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 flex items-center gap-1.5"
            >
              <Database className="w-3.5 h-3.5 text-blue-600" /> 6-Subj Demo
            </button>
            <button
              type="button"
              onClick={() => handleLoadPreset('cs8')}
              className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5 text-indigo-600" /> 8-Subj CS Preset
            </button>
            <button
              type="button"
              onClick={handleGenerate}
              disabled={isGenerating}
              className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm"
            >
              <Play className="w-3.5 h-3.5" />
              {isGenerating ? 'Solving...' : 'Generate Timetable'}
            </button>
            <button
              type="button"
              onClick={handleExportIcs}
              className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 flex items-center gap-1.5"
            >
              <CalendarIcon className="w-3.5 h-3.5 text-emerald-600" /> Export .ics
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" /> Print / PDF
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-5 space-y-5">
        {/* View Switcher & Filter Strip */}
        <div className="no-print bg-white rounded-xl border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">View Mode:</span>
            <div className="inline-flex rounded-lg bg-slate-100 p-0.5 text-xs font-medium">
              <button
                type="button"
                onClick={() => setViewMode('BATCH')}
                className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 ${
                  viewMode === 'BATCH' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600'
                }`}
              >
                <GraduationCap className="w-3.5 h-3.5" /> Batch View
              </button>
              <button
                type="button"
                onClick={() => setViewMode('FACULTY')}
                className={`px-3 py-1.5 rounded-md flex items-center gap-1.5 ${
                  viewMode === 'FACULTY' ? 'bg-white text-blue-700 shadow-sm' : 'text-slate-600'
                }`}
              >
                <Users className="w-3.5 h-3.5" /> Faculty View
              </button>
            </div>

            {viewMode === 'BATCH' ? (
              <select
                value={selectedBatch}
                onChange={(e) => setSelectedBatch(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium bg-white"
              >
                {batches.map((b) => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            ) : (
              <select
                value={selectedFacultyId}
                onChange={(e) => setSelectedFacultyId(e.target.value)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium bg-white"
              >
                {dataset.faculty.map((f) => (
                  <option key={f.id} value={f.id}>
                    {f.name} ({f.department})
                  </option>
                ))}
              </select>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-600 font-medium">Lunch Break Slot:</span>
            <select
              value={lunchPeriod}
              onChange={(e) => setLunchPeriod(Number(e.target.value))}
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white font-medium"
            >
              <option value={3}>Period 3 (11:00)</option>
              <option value={4}>Period 4 (12:00)</option>
              <option value={5}>Period 5 (14:00)</option>
            </select>
          </div>
        </div>

        {/* Interactive Timetable Grid */}
        <TimetableGrid
          viewMode={viewMode}
          selectedBatch={selectedBatch}
          selectedFacultyId={selectedFacultyId}
          lunchPeriod={lunchPeriod}
          allocations={dataset.allocations}
          subjects={dataset.subjects}
          facultyList={dataset.faculty}
          classrooms={dataset.classrooms}
          clashes={clashes}
          onMoveAllocation={handleMoveAllocation}
          onToggleLock={handleToggleLock}
        />

        {/* Clash Auditor & Resource Manager */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-5">
            <ClashAuditorPanel
              clashes={clashes}
              unallocated={unallocated}
              metrics={metrics}
              statusBanner={statusBanner}
            />
          </div>
          <div className="lg:col-span-7">
            <ResourceManager
              subjects={dataset.subjects}
              facultyList={dataset.faculty}
              classrooms={dataset.classrooms}
              onAddSubject={(subj: Subject) =>
                persistDataset({ ...dataset, subjects: [...dataset.subjects, subj] })
              }
              onUpdateSubject={(id: string, subj: Subject) =>
                persistDataset({ ...dataset, subjects: dataset.subjects.map((item) => item.id === id ? subj : item) })
              }
              onDeleteSubject={(id: string) =>
                persistDataset({
                  ...dataset,
                  subjects: dataset.subjects.filter((s) => s.id !== id),
                  allocations: dataset.allocations.filter((a) => a.subjectId !== id),
                })
              }
              onAddFaculty={(fac: Faculty) =>
                persistDataset({ ...dataset, faculty: [...dataset.faculty, fac] })
              }
              onUpdateFaculty={(id: string, fac: Faculty) =>
                persistDataset({
                  ...dataset,
                  faculty: dataset.faculty.map((item) => item.id === id ? fac : item),
                })
              }
              onDeleteFaculty={(id: string) =>
                persistDataset({
                  ...dataset,
                  faculty: dataset.faculty.filter((f) => f.id !== id),
                  allocations: dataset.allocations.filter((a) => a.facultyId !== id),
                })
              }
              onAddClassroom={(room: Classroom) =>
                persistDataset({ ...dataset, classrooms: [...dataset.classrooms, room] })
              }
              onUpdateClassroom={(id: string, room: Classroom) =>
                persistDataset({
                  ...dataset,
                  classrooms: dataset.classrooms.map((item) => item.id === id ? room : item),
                })
              }
              onDeleteClassroom={(id: string) =>
                persistDataset({
                  ...dataset,
                  classrooms: dataset.classrooms.filter((c) => c.id !== id),
                  allocations: dataset.allocations.filter((a) => a.roomId !== id),
                })
              }
            />
          </div>
        </div>
      </main>
    </div>
  );
}
