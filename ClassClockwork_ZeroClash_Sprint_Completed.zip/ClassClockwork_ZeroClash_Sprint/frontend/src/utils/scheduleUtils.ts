import {
  Classroom,
  DAYS_OF_WEEK,
  DayOfWeek,
  Faculty,
  Subject,
  TimetableAllocation,
} from '../../../shared/types';

export function calculateFacultyGini(
  allocations: TimetableAllocation[],
  facultyList: Faculty[]
): number {
  if (facultyList.length === 0) return 0;
  const hours = facultyList.map((f) =>
    allocations
      .filter((a) => a.facultyId === f.id)
      .reduce((sum, a) => sum + a.duration, 0)
  );
  const total = hours.reduce((acc, h) => acc + h, 0);
  if (total === 0) return 0;

  let absDiffSum = 0;
  for (let i = 0; i < hours.length; i++) {
    for (let j = 0; j < hours.length; j++) {
      absDiffSum += Math.abs(hours[i] - hours[j]);
    }
  }
  return Number((absDiffSum / (2 * hours.length * total)).toFixed(3));
}

const DAY_TO_INDEX: Record<DayOfWeek, number> = {
  Monday: 1,
  Tuesday: 2,
  Wednesday: 3,
  Thursday: 4,
  Friday: 5,
};

const PERIOD_START_TIMES: Record<number, string> = {
  1: '09:00:00',
  2: '10:00:00',
  3: '11:00:00',
  4: '12:00:00',
  5: '14:00:00',
  6: '15:00:00',
};

const PERIOD_END_TIMES: Record<number, string> = {
  1: '09:50:00',
  2: '10:50:00',
  3: '11:50:00',
  4: '12:50:00',
  5: '14:50:00',
  6: '15:50:00',
};

function formatIcsDate(baseMonday: Date, day: DayOfWeek, timeStr: string): string {
  const offsetDays = (DAY_TO_INDEX[day] ?? 1) - 1;
  const dt = new Date(baseMonday);
  dt.setDate(baseMonday.getDate() + offsetDays);
  const [hh, mm, ss] = timeStr.split(':').map(Number);
  dt.setHours(hh, mm, ss, 0);

  const pad = (n: number) => String(n).padStart(2, '0');
  return `${dt.getFullYear()}${pad(dt.getMonth() + 1)}${pad(dt.getDate())}T${pad(dt.getHours())}${pad(dt.getMinutes())}${pad(dt.getSeconds())}`;
}

export function buildIcsCalendar(
  allocations: TimetableAllocation[],
  subjects: Subject[],
  facultyList: Faculty[],
  classrooms: Classroom[],
  title = 'ClassClockwork Timetable'
): string {
  const escapeIcsText = (value: string) => value
    .replace(/\\/g, '\\\\')
    .replace(/\r\n|\r|\n/g, '\\n')
    .replace(/,/g, '\\,')
    .replace(/;/g, '\\;');
  const safeUid = (value: string) => value.replace(/[^a-zA-Z0-9._-]/g, '_') || 'class';
  const subjMap = new Map(subjects.map((s) => [s.id, s]));
  const facMap = new Map(facultyList.map((f) => [f.id, f]));
  const roomMap = new Map(classrooms.map((c) => [c.id, c]));

  // Next Monday anchor
  const now = new Date();
  const monday = new Date(now);
  const dayNum = now.getDay();
  const diffToMonday = dayNum === 0 ? 1 : (8 - dayNum) % 7 || 7;
  monday.setDate(now.getDate() + diffToMonday);

  const lines: string[] = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//ClassClockwork//ZeroClash Sprint//EN',
    `X-WR-CALNAME:${escapeIcsText(title)}`,
  ];

  for (const alloc of allocations) {
    const subj = subjMap.get(alloc.subjectId);
    const fac = facMap.get(alloc.facultyId);
    const room = roomMap.get(alloc.roomId);
    const endPeriod = Math.min(6, alloc.startPeriod + alloc.duration - 1);

    const startStr = PERIOD_START_TIMES[alloc.startPeriod] ?? '09:00:00';
    const endStr = PERIOD_END_TIMES[endPeriod] ?? '09:50:00';

    const dtStart = formatIcsDate(monday, alloc.day, startStr);
    const dtEnd = formatIcsDate(monday, alloc.day, endStr);

    const summary = `${subj?.code ?? alloc.subjectId} (${alloc.kind}) - ${subj?.name ?? ''}`.trim();
    const description = `Batch: ${alloc.batch} | Faculty: ${fac?.name ?? alloc.facultyId} | Slot: ${alloc.day} P${alloc.startPeriod}${alloc.duration > 1 ? `–P${endPeriod}` : ''}`;
    const location = room ? `${room.name} (${room.building})` : alloc.roomId;

    lines.push(
      'BEGIN:VEVENT',
      `UID:${safeUid(alloc.id)}@classclockwork.local`,
      `DTSTART:${dtStart}`,
      `DTEND:${dtEnd}`,
      'RRULE:FREQ=WEEKLY;COUNT=12',
      `SUMMARY:${escapeIcsText(summary)}`,
      `DESCRIPTION:${escapeIcsText(description)}`,
      `LOCATION:${escapeIcsText(location)}`,
      'END:VEVENT'
    );
  }

  lines.push('END:VCALENDAR');
  return lines.join('\r\n');
}

export function downloadTextFile(filename: string, content: string, mimeType = 'text/calendar;charset=utf-8'): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

export function getPeriodLabel(period: number): string {
  const map: Record<number, string> = {
    1: 'P1 (09:00)',
    2: 'P2 (10:00)',
    3: 'P3 (11:00)',
    4: 'P4 (12:00)',
    5: 'P5 (14:00)',
    6: 'P6 (15:00)',
  };
  return map[period] ?? `P${period}`;
}

export { DAYS_OF_WEEK };
