export type DayOfWeek = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';

export const DAYS_OF_WEEK: DayOfWeek[] = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
];

export const PERIODS_PER_DAY = 6;

export type SessionKind = 'LECTURE' | 'LAB';

export interface TimeSlot {
  day: DayOfWeek;
  period: number; // 1-indexed: 1..6
}

export interface Faculty {
  id: string;
  name: string;
  department: string;
  maxWeeklyHours: number;
  /** Map of DayOfWeek -> array of allowed period numbers (1..6). If omitted for a day, all periods allowed unless restricted. */
  availability: Partial<Record<DayOfWeek, number[]>>;
  preferredTimeOfDay?: 'MORNING' | 'AFTERNOON' | 'ANY';
  color?: string;
}

export interface Subject {
  id: string;
  code: string;
  name: string;
  batch: string;
  batchSize: number;
  credits: number;
  lectureHoursPerWeek: number;
  /** Number of continuous periods per lab block (e.g., 3 for a 3-hour OS lab). 0 if no lab. */
  labBlockSize: number;
  /** Number of lab blocks per week (usually 0 or 1). */
  labBlocksPerWeek: number;
  requiredEquipment: string[];
  facultyId: string;
  preferredRoomId?: string;
}

export interface Classroom {
  id: string;
  name: string;
  building: string;
  capacity: number;
  isLab: boolean;
  equipment: string[];
}

export interface TimetableAllocation {
  id: string;
  subjectId: string;
  facultyId: string;
  roomId: string;
  batch: string;
  kind: SessionKind;
  day: DayOfWeek;
  /** Starting period (1..6) */
  startPeriod: number;
  /** Duration in periods (1 for lecture, labBlockSize for lab) */
  duration: number;
  isLocked?: boolean;
}

export type ClashSeverity = 'ERROR' | 'WARNING';

export type ClashType =
  | 'FACULTY_DOUBLE_BOOKED'
  | 'ROOM_DOUBLE_BOOKED'
  | 'BATCH_DOUBLE_BOOKED'
  | 'CAPACITY_EXCEEDED'
  | 'MISSING_EQUIPMENT'
  | 'LAB_ROOM_MISMATCH'
  | 'FACULTY_UNAVAILABLE'
  | 'WORKLOAD_EXCEEDED'
  | 'OUT_OF_BOUNDS'
  | 'INVALID_ALLOCATION';

export interface ClashViolation {
  id: string;
  type: ClashType;
  severity: ClashSeverity;
  message: string;
  allocationIds: string[];
  day?: DayOfWeek;
  period?: number;
  facultyId?: string;
  roomId?: string;
  batch?: string;
}

export interface UnallocatedItem {
  subjectId: string;
  subjectCode: string;
  subjectName: string;
  batch: string;
  kind: SessionKind;
  duration: number;
  reason: string;
}

export interface SolverMetrics {
  elapsedMs: number;
  backtracks: number;
  nodesExplored: number;
  timedOut: boolean;
  softPreferenceScore: number; // 0..100
  facultyGiniCoefficient: number; // 0 = perfectly equal, closer to 0 is better
  lunchComplianceRate: number; // 0..100%
}

export interface SolverResult {
  success: boolean;
  allocations: TimetableAllocation[];
  unallocated: UnallocatedItem[];
  clashes: ClashViolation[];
  metrics: SolverMetrics;
  message: string;
}

export interface TimetableDataset {
  id: string;
  name: string;
  description: string;
  subjects: Subject[];
  faculty: Faculty[];
  classrooms: Classroom[];
  allocations: TimetableAllocation[];
  updatedAt: string;
}
