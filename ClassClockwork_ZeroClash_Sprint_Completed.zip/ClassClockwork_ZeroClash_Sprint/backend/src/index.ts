import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import { apiRouter } from './routes/api';

const app = express();
const PORT = Number(process.env.PORT) || 4000;

app.use(
  cors({
    origin: ['http://localhost:5173', 'http://127.0.0.1:5173'],
    methods: ['GET', 'POST', 'PUT', 'OPTIONS'],
    allowedHeaders: ['Content-Type'],
  })
);
app.use(express.json({ limit: '2mb' }));

app.use('/api', apiRouter);

app.use((err: Error & { status?: number; type?: string }, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status === 400 || err.type === 'entity.parse.failed' ? 400 : 500;
  if (status === 500) console.error('Unhandled server error:', err);
  res.status(status).json({
    error: status === 400 ? 'Request body must contain valid JSON.' : 'Internal server error.',
  });
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`ClassClockwork backend listening on http://127.0.0.1:${PORT}`);
});
