import { Router, Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import {
  Classroom,
  DAYS_OF_WEEK,
  Faculty,
  Subject,
  TimetableAllocation,
  TimetableDataset,
} from '../../../shared/types';
import { detectClashes } from '../solver/clashAuditor';
import { solveTimetableCSP } from '../solver/cspSolver';
import {
  getActiveDataset,
  getAllDatasets,
  setActiveDataset,
  upsertDataset,
} from '../storage/jsonStore';
import { DEMO_6_SUBJECT_DATASET, SAMPLE_CS_SEMESTER_DATASET } from '../data/sampleData';

export const apiRouter = Router();

type RecordValue = Record<string, unknown>;

function isRecord(value: unknown): value is RecordValue {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function isNonEmptyString(val: unknown): val is string {
  return typeof val === 'string' && val.trim().length > 0;
}

function isPositiveNumber(val: unknown): val is number {
  return typeof val === 'number' && Number.isFinite(val) && val > 0;
}

function isStringList(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((entry) => typeof entry === 'string' && entry.length <= 120);
}

function isAvailability(value: unknown): value is Faculty['availability'] {
  if (!isRecord(value)) return false;
  return Object.entries(value).every(([day, periods]) =>
    DAYS_OF_WEEK.includes(day as (typeof DAYS_OF_WEEK)[number]) &&
    Array.isArray(periods) &&
    periods.every((period) => Number.isInteger(period) && Number(period) >= 1 && Number(period) <= 6)
  );
}

function isFacultyValue(value: unknown): value is Faculty {
  if (!isRecord(value)) return false;
  const availability = value.availability;
  return isNonEmptyString(value.id) && value.id.length <= 80 &&
    isNonEmptyString(value.name) && value.name.length <= 120 &&
    typeof value.department === 'string' && value.department.length <= 120 &&
    isPositiveNumber(value.maxWeeklyHours) && value.maxWeeklyHours <= 40 &&
    isAvailability(availability) &&
    (value.preferredTimeOfDay === undefined || ['ANY', 'MORNING', 'AFTERNOON'].includes(String(value.preferredTimeOfDay))) &&
    (value.color === undefined || (typeof value.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(value.color)));
}

function isSubjectValue(value: unknown): value is Subject {
  return isRecord(value) &&
    isNonEmptyString(value.id) && value.id.length <= 80 &&
    isNonEmptyString(value.code) && value.code.length <= 40 &&
    isNonEmptyString(value.name) && value.name.length <= 160 &&
    isNonEmptyString(value.batch) && value.batch.length <= 80 &&
    Number.isInteger(value.batchSize) && Number(value.batchSize) >= 1 && Number(value.batchSize) <= 1000 &&
    Number.isInteger(value.credits) && Number(value.credits) >= 0 && Number(value.credits) <= 100 &&
    Number.isInteger(value.lectureHoursPerWeek) && Number(value.lectureHoursPerWeek) >= 0 && Number(value.lectureHoursPerWeek) <= 30 &&
    Number.isInteger(value.labBlockSize) && Number(value.labBlockSize) >= 0 && Number(value.labBlockSize) <= 6 &&
    Number.isInteger(value.labBlocksPerWeek) && Number(value.labBlocksPerWeek) >= 0 && Number(value.labBlocksPerWeek) <= 5 &&
    isStringList(value.requiredEquipment) &&
    isNonEmptyString(value.facultyId) &&
    (value.preferredRoomId === undefined || (typeof value.preferredRoomId === 'string' && value.preferredRoomId.length <= 80));
}

function isClassroomValue(value: unknown): value is Classroom {
  return isRecord(value) &&
    isNonEmptyString(value.id) && value.id.length <= 80 &&
    isNonEmptyString(value.name) && value.name.length <= 120 &&
    typeof value.building === 'string' && value.building.length <= 120 &&
    Number.isInteger(value.capacity) && Number(value.capacity) >= 1 && Number(value.capacity) <= 500 &&
    typeof value.isLab === 'boolean' && isStringList(value.equipment);
}

function isAllocationValue(value: unknown): value is TimetableAllocation {
  return isRecord(value) &&
    isNonEmptyString(value.id) && value.id.length <= 100 &&
    isNonEmptyString(value.subjectId) && isNonEmptyString(value.facultyId) &&
    isNonEmptyString(value.roomId) && isNonEmptyString(value.batch) &&
    (value.kind === 'LECTURE' || value.kind === 'LAB') &&
    DAYS_OF_WEEK.includes(value.day as (typeof DAYS_OF_WEEK)[number]) &&
    Number.isInteger(value.startPeriod) && Number(value.startPeriod) >= 1 && Number(value.startPeriod) <= 6 &&
    Number.isInteger(value.duration) && Number(value.duration) >= 1 && Number(value.duration) <= 6 &&
    (value.isLocked === undefined || typeof value.isLocked === 'boolean');
}

function isArrayOf<T>(value: unknown, validator: (entry: unknown) => entry is T, max: number): value is T[] {
  return Array.isArray(value) && value.length <= max && value.every(validator);
}

apiRouter.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'ClassClockwork CSP Engine', timestamp: new Date().toISOString() });
});

apiRouter.get('/datasets', (_req: Request, res: Response) => {
  const data = getAllDatasets();
  res.json(data);
});

apiRouter.get('/dataset/active', (_req: Request, res: Response) => {
  const active = getActiveDataset();
  res.json(active);
});

apiRouter.post('/dataset/active', (req: Request, res: Response) => {
  const { datasetId } = (req.body ?? {}) as { datasetId?: string };
  if (!isNonEmptyString(datasetId)) {
    res.status(400).json({ error: 'datasetId is required.' });
    return;
  }
  const updated = setActiveDataset(datasetId);
  if (!updated) {
    res.status(404).json({ error: `Dataset '${datasetId}' not found.` });
    return;
  }
  res.json(updated);
});

apiRouter.post('/dataset/load-preset', (req: Request, res: Response) => {
  const { preset } = (req.body ?? {}) as { preset?: 'demo6' | 'cs8' };
  if (preset !== 'demo6' && preset !== 'cs8') {
    res.status(400).json({ error: 'Choose the demo6 or cs8 preset.' });
    return;
  }
  const source =
    preset === 'cs8'
      ? { ...SAMPLE_CS_SEMESTER_DATASET, allocations: [], updatedAt: new Date().toISOString() }
      : { ...DEMO_6_SUBJECT_DATASET, allocations: [], updatedAt: new Date().toISOString() };
  const saved = upsertDataset(source);
  res.json(saved);
});

apiRouter.put('/dataset', (req: Request, res: Response) => {
  const body = (req.body ?? {}) as Partial<TimetableDataset>;
  if (
    !isArrayOf(body.subjects, isSubjectValue, 500) ||
    !isArrayOf(body.faculty, isFacultyValue, 500) ||
    !isArrayOf(body.classrooms, isClassroomValue, 500) ||
    (body.allocations !== undefined && !isArrayOf(body.allocations, isAllocationValue, 4000))
  ) {
    res.status(400).json({ error: 'Invalid dataset. Check resource fields and keep the data within supported limits.' });
    return;
  }

  const current = getActiveDataset();
  const nextDataset: TimetableDataset = {
    id: isNonEmptyString(body.id) ? body.id : current.id,
    name: isNonEmptyString(body.name) ? body.name : current.name,
    description: typeof body.description === 'string' ? body.description : current.description,
    subjects: body.subjects,
    faculty: body.faculty,
    classrooms: body.classrooms,
    allocations: body.allocations ?? current.allocations,
    updatedAt: new Date().toISOString(),
  };

  const saved = upsertDataset(nextDataset);
  res.json(saved);
});

apiRouter.post('/resources/faculty', (req: Request, res: Response) => {
  const body = (req.body ?? {}) as Partial<Faculty>;
  if (!isNonEmptyString(body.name) || !isPositiveNumber(body.maxWeeklyHours)) {
    res.status(400).json({ error: 'Faculty name and positive maxWeeklyHours are required.' });
    return;
  }
  const dataset = getActiveDataset();
  const newFaculty: Faculty = {
    id: isNonEmptyString(body.id) ? body.id.slice(0, 80) : `fac-${uuidv4().slice(0, 8)}`,
    name: body.name.trim().slice(0, 120),
    department: isNonEmptyString(body.department) ? body.department.trim().slice(0, 120) : 'CSE',
    maxWeeklyHours: Math.max(1, Math.min(40, Math.round(body.maxWeeklyHours))),
    availability: isAvailability(body.availability) ? body.availability : {
      Monday: [1, 2, 3, 4, 5, 6],
      Tuesday: [1, 2, 3, 4, 5, 6],
      Wednesday: [1, 2, 3, 4, 5, 6],
      Thursday: [1, 2, 3, 4, 5, 6],
      Friday: [1, 2, 3, 4, 5, 6],
    },
    preferredTimeOfDay: body.preferredTimeOfDay === 'MORNING' || body.preferredTimeOfDay === 'AFTERNOON'
      ? body.preferredTimeOfDay
      : 'ANY',
    color: typeof body.color === 'string' && /^#[0-9a-fA-F]{6}$/.test(body.color) ? body.color : '#2563eb',
  };
  dataset.faculty.push(newFaculty);
  const saved = upsertDataset(dataset);
  res.status(201).json({ faculty: newFaculty, dataset: saved });
});

apiRouter.post('/resources/subjects', (req: Request, res: Response) => {
  const body = (req.body ?? {}) as Partial<Subject>;
  if (
    !isNonEmptyString(body.code) ||
    !isNonEmptyString(body.name) ||
    !isNonEmptyString(body.batch) ||
    !isNonEmptyString(body.facultyId)
  ) {
    res.status(400).json({ error: 'Subject code, name, batch, and facultyId are required.' });
    return;
  }
  const dataset = getActiveDataset();
  const newSubject: Subject = {
    id: isNonEmptyString(body.id) ? body.id.slice(0, 80) : `sub-${uuidv4().slice(0, 8)}`,
    code: body.code.trim().toUpperCase().slice(0, 40),
    name: body.name.trim().slice(0, 160),
    batch: body.batch.trim().slice(0, 80),
    batchSize: isPositiveNumber(body.batchSize) ? Math.max(1, Math.round(body.batchSize)) : 50,
    credits: isPositiveNumber(body.credits) ? Math.round(body.credits) : 3,
    lectureHoursPerWeek:
      typeof body.lectureHoursPerWeek === 'number' && body.lectureHoursPerWeek >= 0
        ? Math.min(10, Math.round(body.lectureHoursPerWeek))
        : 3,
    labBlockSize:
      typeof body.labBlockSize === 'number' && body.labBlockSize >= 0
        ? Math.min(6, Math.round(body.labBlockSize))
        : 0,
    labBlocksPerWeek:
      typeof body.labBlocksPerWeek === 'number' && body.labBlocksPerWeek >= 0
        ? Math.min(3, Math.round(body.labBlocksPerWeek))
        : 0,
    requiredEquipment: Array.isArray(body.requiredEquipment)
      ? body.requiredEquipment.filter((e): e is string => typeof e === 'string').map((e) => e.trim().slice(0, 120)).filter(Boolean).slice(0, 30)
      : [],
    facultyId: body.facultyId.trim(),
    preferredRoomId: typeof body.preferredRoomId === 'string' ? body.preferredRoomId.trim() : undefined,
  };
  dataset.subjects.push(newSubject);
  const saved = upsertDataset(dataset);
  res.status(201).json({ subject: newSubject, dataset: saved });
});

apiRouter.post('/resources/classrooms', (req: Request, res: Response) => {
  const body = (req.body ?? {}) as Partial<Classroom>;
  if (!isNonEmptyString(body.name) || !isPositiveNumber(body.capacity)) {
    res.status(400).json({ error: 'Classroom name and positive capacity are required.' });
    return;
  }
  const dataset = getActiveDataset();
  const newRoom: Classroom = {
    id: isNonEmptyString(body.id) ? body.id.slice(0, 80) : `room-${uuidv4().slice(0, 8)}`,
    name: body.name.trim().slice(0, 120),
    building: isNonEmptyString(body.building) ? body.building.trim().slice(0, 120) : 'Main Block',
    capacity: Math.min(500, Math.max(1, Math.round(body.capacity))),
    isLab: body.isLab === true,
    equipment: Array.isArray(body.equipment)
      ? body.equipment.filter((e): e is string => typeof e === 'string').map((e) => e.trim().slice(0, 120)).filter(Boolean).slice(0, 30)
      : ['Projector'],
  };
  dataset.classrooms.push(newRoom);
  const saved = upsertDataset(dataset);
  res.status(201).json({ classroom: newRoom, dataset: saved });
});

apiRouter.post('/timetable/generate', (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    subjects?: Subject[];
    faculty?: Faculty[];
    classrooms?: Classroom[];
    preserveLocked?: boolean;
    lockedAllocations?: TimetableAllocation[];
    lunchPeriod?: number;
  };
  if (
    (body.subjects !== undefined && !isArrayOf(body.subjects, isSubjectValue, 500)) ||
    (body.faculty !== undefined && !isArrayOf(body.faculty, isFacultyValue, 500)) ||
    (body.classrooms !== undefined && !isArrayOf(body.classrooms, isClassroomValue, 500)) ||
    (body.lockedAllocations !== undefined && !isArrayOf(body.lockedAllocations, isAllocationValue, 4000)) ||
    (body.lunchPeriod !== undefined && (!Number.isInteger(body.lunchPeriod) || body.lunchPeriod < 1 || body.lunchPeriod > 6))
  ) {
    res.status(400).json({ error: 'Invalid scheduling input. Check resource values and lunch period.' });
    return;
  }
  const current = getActiveDataset();
  const subjects = Array.isArray(body.subjects) ? body.subjects : current.subjects;
  const facultyList = Array.isArray(body.faculty) ? body.faculty : current.faculty;
  const classrooms = Array.isArray(body.classrooms) ? body.classrooms : current.classrooms;
  const locked = body.preserveLocked
    ? (body.lockedAllocations ?? current.allocations.filter((a) => a.isLocked)).filter((a) => a.isLocked)
    : [];

  const result = solveTimetableCSP(subjects, facultyList, classrooms, locked, {
    lunchPeriod: typeof body.lunchPeriod === 'number' ? body.lunchPeriod : 4,
  });

  const updatedDataset: TimetableDataset = {
    ...current,
    subjects,
    faculty: facultyList,
    classrooms,
    allocations: result.allocations,
    updatedAt: new Date().toISOString(),
  };
  const savedDataset = upsertDataset(updatedDataset);

  res.json({ result, dataset: savedDataset });
});

apiRouter.post('/timetable/validate', (req: Request, res: Response) => {
  const body = (req.body ?? {}) as {
    allocations?: TimetableAllocation[];
    subjects?: Subject[];
    faculty?: Faculty[];
    classrooms?: Classroom[];
  };
  if (
    (body.allocations !== undefined && !isArrayOf(body.allocations, isAllocationValue, 4000)) ||
    (body.subjects !== undefined && !isArrayOf(body.subjects, isSubjectValue, 500)) ||
    (body.faculty !== undefined && !isArrayOf(body.faculty, isFacultyValue, 500)) ||
    (body.classrooms !== undefined && !isArrayOf(body.classrooms, isClassroomValue, 500))
  ) {
    res.status(400).json({ error: 'Invalid timetable validation payload.' });
    return;
  }
  const current = getActiveDataset();
  const allocations = Array.isArray(body.allocations) ? body.allocations : current.allocations;
  const subjects = Array.isArray(body.subjects) ? body.subjects : current.subjects;
  const facultyList = Array.isArray(body.faculty) ? body.faculty : current.faculty;
  const classrooms = Array.isArray(body.classrooms) ? body.classrooms : current.classrooms;

  const clashes = detectClashes(allocations, subjects, facultyList, classrooms);
  res.json({ clashes });
});

apiRouter.put('/timetable/allocations', (req: Request, res: Response) => {
  const body = (req.body ?? {}) as { allocations?: TimetableAllocation[] };
  if (!isArrayOf(body.allocations, isAllocationValue, 4000)) {
    res.status(400).json({ error: 'allocations array is required.' });
    return;
  }
  const current = getActiveDataset();
  const clashes = detectClashes(body.allocations, current.subjects, current.faculty, current.classrooms);
  const updatedDataset: TimetableDataset = {
    ...current,
    allocations: body.allocations,
    updatedAt: new Date().toISOString(),
  };
  const savedDataset = upsertDataset(updatedDataset);
  res.json({ dataset: savedDataset, clashes });
});
