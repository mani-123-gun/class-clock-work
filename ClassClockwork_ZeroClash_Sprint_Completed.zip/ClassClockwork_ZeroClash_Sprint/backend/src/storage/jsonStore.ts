import fs from 'fs';
import path from 'path';
import { TimetableDataset } from '../../../shared/types';
import { DEMO_6_SUBJECT_DATASET, SAMPLE_CS_SEMESTER_DATASET } from '../data/sampleData';

const DATA_DIR = path.resolve(__dirname, '../../data');
const STORE_FILE = path.join(DATA_DIR, 'timetable_store.json');

interface StoreSchema {
  activeDatasetId: string;
  datasets: Record<string, TimetableDataset>;
}

function ensureStore(): StoreSchema {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(STORE_FILE)) {
    const initial: StoreSchema = {
      activeDatasetId: DEMO_6_SUBJECT_DATASET.id,
      datasets: {
        [DEMO_6_SUBJECT_DATASET.id]: DEMO_6_SUBJECT_DATASET,
        [SAMPLE_CS_SEMESTER_DATASET.id]: SAMPLE_CS_SEMESTER_DATASET,
      },
    };
    fs.writeFileSync(STORE_FILE, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }

  try {
    const raw = fs.readFileSync(STORE_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as StoreSchema;
    if (!parsed.datasets || typeof parsed.datasets !== 'object' || Array.isArray(parsed.datasets)) {
      throw new Error('Invalid store structure');
    }
    return parsed;
  } catch {
    try {
      fs.renameSync(STORE_FILE, `${STORE_FILE}.corrupt-${Date.now()}.json`);
    } catch {
      // Continue with the bundled sample if the damaged file cannot be preserved.
    }
    const fallback: StoreSchema = {
      activeDatasetId: DEMO_6_SUBJECT_DATASET.id,
      datasets: {
        [DEMO_6_SUBJECT_DATASET.id]: DEMO_6_SUBJECT_DATASET,
        [SAMPLE_CS_SEMESTER_DATASET.id]: SAMPLE_CS_SEMESTER_DATASET,
      },
    };
    fs.writeFileSync(STORE_FILE, JSON.stringify(fallback, null, 2), 'utf-8');
    return fallback;
  }
}

function saveStore(store: StoreSchema): void {
  const tempFile = `${STORE_FILE}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(store, null, 2), 'utf-8');
  fs.renameSync(tempFile, STORE_FILE);
}

export function getAllDatasets(): { activeDatasetId: string; datasets: TimetableDataset[] } {
  const store = ensureStore();
  return {
    activeDatasetId: store.activeDatasetId,
    datasets: Object.values(store.datasets),
  };
}

export function getActiveDataset(): TimetableDataset {
  const store = ensureStore();
  return (
    store.datasets[store.activeDatasetId] ??
    Object.values(store.datasets)[0] ??
    DEMO_6_SUBJECT_DATASET
  );
}

export function setActiveDataset(datasetId: string): TimetableDataset | null {
  const store = ensureStore();
  if (!store.datasets[datasetId]) return null;
  store.activeDatasetId = datasetId;
  saveStore(store);
  return store.datasets[datasetId];
}

export function upsertDataset(dataset: TimetableDataset): TimetableDataset {
  const store = ensureStore();
  const safeId = dataset.id.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 64) || 'custom-dataset';
  const normalized: TimetableDataset = {
    ...dataset,
    id: safeId,
    updatedAt: new Date().toISOString(),
  };
  store.datasets[safeId] = normalized;
  store.activeDatasetId = safeId;
  saveStore(store);
  return normalized;
}
