import { v4 as uuidv4 } from 'uuid';
import {
  Classroom,
  DAYS_OF_WEEK,
  DayOfWeek,
  Faculty,
  PERIODS_PER_DAY,
  SessionKind,
  SolverMetrics,
  SolverResult,
  Subject,
  TimetableAllocation,
  UnallocatedItem,
} from '../../../shared/types';
import { detectClashes } from './clashAuditor';

interface SchedulingTask {
  id: string;
  subject: Subject;
  faculty: Faculty;
  kind: SessionKind;
  duration: number;
  candidateRooms: Classroom[];
  domainSlots: Array<{ day: DayOfWeek; startPeriod: number; room: Classroom; score: number }>;
}

export interface SolverOptions {
  maxBacktracks?: number;
  timeoutMs?: number;
  lunchPeriod?: number; // e.g., period 4 is preferred free/break slot if possible
}

function computeGini(values: number[]): number {
  if (values.length === 0) return 0;
  const sum = values.reduce((acc, v) => acc + v, 0);
  if (sum === 0) return 0;
  let diffSum = 0;
  for (let i = 0; i < values.length; i++) {
    for (let j = 0; j < values.length; j++) {
      diffSum += Math.abs(values[i] - values[j]);
    }
  }
  return Number((diffSum / (2 * values.length * sum)).toFixed(3));
}

function scoreSlotPreference(
  faculty: Faculty,
  day: DayOfWeek,
  startPeriod: number,
  duration: number,
  kind: SessionKind,
  room: Classroom,
  subject: Subject,
  lunchPeriod: number
): number {
  let score = 50;
  const midPeriod = startPeriod + (duration - 1) / 2;
  const isMorning = midPeriod <= 3.5;

  if (kind === 'LAB') {
    // Prefer afternoon blocks (periods 4..6) for multi-hour labs so mornings stay clean for lectures
    if (startPeriod >= 4) score += 20;
  } else if (faculty.preferredTimeOfDay === 'MORNING' && isMorning) {
    score += 15;
  } else if (faculty.preferredTimeOfDay === 'AFTERNOON' && !isMorning) {
    score += 15;
  }

  // Soft lunch awareness: slight preference not to bisect or crowd lunch period unless needed
  const coversLunch =
    lunchPeriod >= startPeriod && lunchPeriod < startPeriod + duration;
  if (!coversLunch) {
    score += 5;
  }

  if (subject.preferredRoomId && subject.preferredRoomId === room.id) {
    score += 10;
  }

  // Prefer right-sized rooms over huge over-capacity rooms
  const slack = Math.max(0, room.capacity - subject.batchSize);
  score -= Math.min(15, Math.floor(slack / 10));

  return score;
}

function buildTasks(
  subjects: Subject[],
  facultyList: Faculty[],
  classrooms: Classroom[],
  lunchPeriod: number
): { tasks: SchedulingTask[]; unbuildable: UnallocatedItem[] } {
  const facultyMap = new Map(facultyList.map((f) => [f.id, f]));
  const tasks: SchedulingTask[] = [];
  const unbuildable: UnallocatedItem[] = [];

  for (const subj of subjects) {
    const fac = facultyMap.get(subj.facultyId);
    if (!fac) {
      const reason = `Assigned faculty (${subj.facultyId}) not found.`;
      for (let l = 0; l < subj.lectureHoursPerWeek; l++) {
        unbuildable.push({
          subjectId: subj.id,
          subjectCode: subj.code,
          subjectName: subj.name,
          batch: subj.batch,
          kind: 'LECTURE',
          duration: 1,
          reason,
        });
      }
      for (let b = 0; b < subj.labBlocksPerWeek; b++) {
        unbuildable.push({
          subjectId: subj.id,
          subjectCode: subj.code,
          subjectName: subj.name,
          batch: subj.batch,
          kind: 'LAB',
          duration: Math.max(1, subj.labBlockSize),
          reason,
        });
      }
      continue;
    }

    // Build lab macro-slot tasks first (atomic multi-period blocks)
    if (subj.labBlocksPerWeek > 0 && subj.labBlockSize <= 0) {
      for (let b = 0; b < subj.labBlocksPerWeek; b++) {
        unbuildable.push({
          subjectId: subj.id,
          subjectCode: subj.code,
          subjectName: subj.name,
          batch: subj.batch,
          kind: 'LAB',
          duration: 1,
          reason: 'Lab blocks are required, but the lab duration is not configured.',
        });
      }
    } else if (subj.labBlocksPerWeek > 0) {
      const labRooms = classrooms.filter(
        (c) =>
          c.isLab &&
          c.capacity >= subj.batchSize &&
          subj.requiredEquipment.every((req) =>
            c.equipment.some((re) => re.toLowerCase() === req.toLowerCase())
          )
      );

      for (let b = 0; b < subj.labBlocksPerWeek; b++) {
        const domainSlots: SchedulingTask['domainSlots'] = [];
        for (const day of DAYS_OF_WEEK) {
          const allowed = fac.availability[day] ?? [1, 2, 3, 4, 5, 6];
          for (let start = 1; start <= PERIODS_PER_DAY - subj.labBlockSize + 1; start++) {
            const needed = Array.from({ length: subj.labBlockSize }, (_, idx) => start + idx);
            if (!needed.every((p) => allowed.includes(p))) continue;

            for (const room of labRooms) {
              domainSlots.push({
                day,
                startPeriod: start,
                room,
                score: scoreSlotPreference(
                  fac,
                  day,
                  start,
                  subj.labBlockSize,
                  'LAB',
                  room,
                  subj,
                  lunchPeriod
                ),
              });
            }
          }
        }
        domainSlots.sort((a, bSlot) => bSlot.score - a.score);

        if (domainSlots.length === 0) {
          unbuildable.push({
            subjectId: subj.id,
            subjectCode: subj.code,
            subjectName: subj.name,
            batch: subj.batch,
            kind: 'LAB',
            duration: subj.labBlockSize,
            reason: `No valid ${subj.labBlockSize}-period lab slot/room/faculty availability found.`,
          });
        } else {
          tasks.push({
            id: `${subj.id}-lab-${b + 1}`,
            subject: subj,
            faculty: fac,
            kind: 'LAB',
            duration: subj.labBlockSize,
            candidateRooms: labRooms,
            domainSlots,
          });
        }
      }
    }

    // Build single-period lecture tasks
    const lectureRooms = classrooms.filter(
      (c) =>
        c.capacity >= subj.batchSize &&
        subj.requiredEquipment.every((req) =>
          c.equipment.some((re) => re.toLowerCase() === req.toLowerCase())
        )
    );

    for (let l = 0; l < subj.lectureHoursPerWeek; l++) {
      const domainSlots: SchedulingTask['domainSlots'] = [];
      for (const day of DAYS_OF_WEEK) {
          const allowed = fac.availability[day] ?? [1, 2, 3, 4, 5, 6];
        for (let start = 1; start <= PERIODS_PER_DAY; start++) {
          if (!allowed.includes(start)) continue;
          for (const room of lectureRooms) {
            domainSlots.push({
              day,
              startPeriod: start,
              room,
              score: scoreSlotPreference(
                fac,
                day,
                start,
                1,
                'LECTURE',
                room,
                subj,
                lunchPeriod
              ),
            });
          }
        }
      }
      domainSlots.sort((a, bSlot) => bSlot.score - a.score);

      if (domainSlots.length === 0) {
        unbuildable.push({
          subjectId: subj.id,
          subjectCode: subj.code,
          subjectName: subj.name,
          batch: subj.batch,
          kind: 'LECTURE',
          duration: 1,
          reason: `No valid 1-period lecture slot/room/faculty availability found.`,
        });
      } else {
        tasks.push({
          id: `${subj.id}-lec-${l + 1}`,
          subject: subj,
          faculty: fac,
          kind: 'LECTURE',
          duration: 1,
          candidateRooms: lectureRooms,
          domainSlots,
        });
      }
    }
  }

  // Sort tasks initially by LAB first, then smallest domain (MRV)
  tasks.sort((a, b) => {
    if (a.kind !== b.kind) return a.kind === 'LAB' ? -1 : 1;
    return a.domainSlots.length - b.domainSlots.length;
  });

  return { tasks, unbuildable };
}

export function solveTimetableCSP(
  subjects: Subject[],
  facultyList: Faculty[],
  classrooms: Classroom[],
  lockedAllocations: TimetableAllocation[] = [],
  options: SolverOptions = {}
): SolverResult {
  const startTime = Date.now();
  const maxBacktracks = options.maxBacktracks ?? 8000;
  const timeoutMs = options.timeoutMs ?? 1400;
  const lunchPeriod = options.lunchPeriod ?? 4;

  const { tasks: allTasks, unbuildable } = buildTasks(subjects, facultyList, classrooms, lunchPeriod);

  // A locked allocation satisfies one matching required session. Without this
  // accounting, regenerating a timetable would schedule every locked class twice.
  const lockedCounts = new Map<string, number>();
  for (const allocation of lockedAllocations) {
    const key = `${allocation.subjectId}|${allocation.kind}|${allocation.duration}`;
    lockedCounts.set(key, (lockedCounts.get(key) ?? 0) + 1);
  }
  const tasks: SchedulingTask[] = [];
  for (const task of allTasks) {
    const key = `${task.subject.id}|${task.kind}|${task.duration}`;
    const remainingLocked = lockedCounts.get(key) ?? 0;
    if (remainingLocked > 0) {
      lockedCounts.set(key, remainingLocked - 1);
    } else {
      tasks.push(task);
    }
  }

  // Occupancy sets built from locked + assigned allocations
  const facultyBusy = new Set<string>();
  const roomBusy = new Set<string>();
  const batchBusy = new Set<string>();
  const facultyAssignedHours = new Map<string, number>();
  const batchDaySubjectCount = new Map<string, number>();

  const markOccupancy = (
    facultyId: string,
    roomId: string,
    batch: string,
    subjectId: string,
    day: DayOfWeek,
    startPeriod: number,
    duration: number,
    delta: 1 | -1
  ) => {
    for (let p = startPeriod; p < startPeriod + duration; p++) {
      const fKey = `${facultyId}|${day}|${p}`;
      const rKey = `${roomId}|${day}|${p}`;
      const bKey = `${batch}|${day}|${p}`;
      if (delta === 1) {
        facultyBusy.add(fKey);
        roomBusy.add(rKey);
        batchBusy.add(bKey);
      } else {
        facultyBusy.delete(fKey);
        roomBusy.delete(rKey);
        batchBusy.delete(bKey);
      }
    }
    facultyAssignedHours.set(
      facultyId,
      (facultyAssignedHours.get(facultyId) ?? 0) + duration * delta
    );
    const sKey = `${batch}|${day}|${subjectId}`;
    batchDaySubjectCount.set(sKey, Math.max(0, (batchDaySubjectCount.get(sKey) ?? 0) + delta));
  };

  for (const locked of lockedAllocations) {
    markOccupancy(
      locked.facultyId,
      locked.roomId,
      locked.batch,
      locked.subjectId,
      locked.day,
      locked.startPeriod,
      locked.duration,
      1
    );
  }

  const isSlotCompatible = (
    task: SchedulingTask,
    day: DayOfWeek,
    startPeriod: number,
    roomId: string,
    enforceSoftDaySpread: boolean
  ): boolean => {
    const currentHours = facultyAssignedHours.get(task.faculty.id) ?? 0;
    if (currentHours + task.duration > task.faculty.maxWeeklyHours) {
      return false;
    }

    for (let p = startPeriod; p < startPeriod + task.duration; p++) {
      if (facultyBusy.has(`${task.faculty.id}|${day}|${p}`)) return false;
      if (roomBusy.has(`${roomId}|${day}|${p}`)) return false;
      if (batchBusy.has(`${task.subject.batch}|${day}|${p}`)) return false;
    }

    if (enforceSoftDaySpread && task.kind === 'LECTURE') {
      const sameDayCount = batchDaySubjectCount.get(`${task.subject.batch}|${day}|${task.subject.id}`) ?? 0;
      if (sameDayCount >= 1) return false;
    }

    return true;
  };

  const countLegalValues = (task: SchedulingTask, enforceSoftDaySpread: boolean): number => {
    let count = 0;
    for (const slot of task.domainSlots) {
      if (isSlotCompatible(task, slot.day, slot.startPeriod, slot.room.id, enforceSoftDaySpread)) {
        count++;
      }
    }
    return count;
  };

  let backtracks = 0;
  let nodesExplored = 0;
  let timedOut = false;
  let bestPartialAssignment: TimetableAllocation[] = [];

  const runSearch = (enforceSoftDaySpread: boolean): TimetableAllocation[] | null => {
    const remaining = new Set<string>(tasks.map((t) => t.id));
    const taskById = new Map<string, SchedulingTask>(tasks.map((t) => [t.id, t]));
    const current: TimetableAllocation[] = [];

    const backtrack = (): boolean => {
      nodesExplored++;
      if (Date.now() - startTime > timeoutMs) {
        timedOut = true;
        return false;
      }
      if (backtracks >= maxBacktracks) {
        return false;
      }

      if (current.length > bestPartialAssignment.length) {
        bestPartialAssignment = [...current];
      }

      if (remaining.size === 0) {
        return true;
      }

      // Minimum Remaining Values (MRV) heuristic: select unassigned task with fewest legal slots
      let chosenTask: SchedulingTask | null = null;
      let minLegal = Infinity;

      for (const id of remaining) {
        const t = taskById.get(id)!;
        const legalCount = countLegalValues(t, enforceSoftDaySpread);
        if (legalCount === 0) {
          return false; // Immediate dead-end prune
        }
        if (legalCount < minLegal) {
          minLegal = legalCount;
          chosenTask = t;
          if (minLegal === 1) break;
        }
      }

      if (!chosenTask) return false;

      // Order candidate values by heuristic preference score
      const legalSlots = chosenTask.domainSlots.filter((s) =>
        isSlotCompatible(chosenTask!, s.day, s.startPeriod, s.room.id, enforceSoftDaySpread)
      );

      for (const slot of legalSlots) {
        const alloc: TimetableAllocation = {
          id: uuidv4(),
          subjectId: chosenTask.subject.id,
          facultyId: chosenTask.faculty.id,
          roomId: slot.room.id,
          batch: chosenTask.subject.batch,
          kind: chosenTask.kind,
          day: slot.day,
          startPeriod: slot.startPeriod,
          duration: chosenTask.duration,
        };

        current.push(alloc);
        remaining.delete(chosenTask.id);
        markOccupancy(
          alloc.facultyId,
          alloc.roomId,
          alloc.batch,
          alloc.subjectId,
          alloc.day,
          alloc.startPeriod,
          alloc.duration,
          1
        );

        if (backtrack()) {
          return true;
        }

        markOccupancy(
          alloc.facultyId,
          alloc.roomId,
          alloc.batch,
          alloc.subjectId,
          alloc.day,
          alloc.startPeriod,
          alloc.duration,
          -1
        );
        remaining.add(chosenTask.id);
        current.pop();
        backtracks++;
      }

      return false;
    };

    const solved = backtrack();
    return solved ? current : null;
  };

  // Pass 1: Strict hard constraints + soft same-day lecture spread
  let solution = runSearch(true);

  // Pass 2: Relax soft same-day spread if needed while keeping all hard constraints intact
  if (!solution && !timedOut && backtracks < maxBacktracks) {
    solution = runSearch(false);
  }

  const finalAllocations: TimetableAllocation[] = [
    ...lockedAllocations,
    ...(solution ?? bestPartialAssignment),
  ];

  // Identify any unallocated tasks
  const allocatedCountByKey = new Map<string, number>();
  for (const a of finalAllocations) {
    const key = `${a.subjectId}|${a.kind}|${a.duration}`;
    allocatedCountByKey.set(key, (allocatedCountByKey.get(key) ?? 0) + 1);
  }

  const unallocated: UnallocatedItem[] = [...unbuildable];
  const taskCounts = new Map<string, { task: SchedulingTask; required: number }>();
  for (const t of allTasks) {
    const key = `${t.subject.id}|${t.kind}|${t.duration}`;
    const prev = taskCounts.get(key);
    if (prev) {
      prev.required += 1;
    } else {
      taskCounts.set(key, { task: t, required: 1 });
    }
  }

  for (const [key, { task, required }] of taskCounts.entries()) {
    const got = allocatedCountByKey.get(key) ?? 0;
    if (got < required) {
      const missing = required - got;
      for (let m = 0; m < missing; m++) {
        unallocated.push({
          subjectId: task.subject.id,
          subjectCode: task.subject.code,
          subjectName: task.subject.name,
          batch: task.subject.batch,
          kind: task.kind,
          duration: task.duration,
          reason:
            'Constraint conflict or faculty/room/time exhaustion; relaxed or left unallocated to prevent invalid clash.',
        });
      }
    }
  }

  const clashes = detectClashes(finalAllocations, subjects, facultyList, classrooms);
  const elapsedMs = Date.now() - startTime;

  const hoursArr = facultyList.map((f) =>
    finalAllocations
      .filter((a) => a.facultyId === f.id)
      .reduce((acc, a) => acc + a.duration, 0)
  );
  const facultyGiniCoefficient = computeGini(hoursArr);

  // Compute lunch compliance across batch-days
  const batches = Array.from(new Set(subjects.map((s) => s.batch)));
  let totalBatchDays = 0;
  let lunchFreeBatchDays = 0;
  for (const batch of batches) {
    for (const day of DAYS_OF_WEEK) {
      totalBatchDays++;
      const busyAtLunch = finalAllocations.some(
        (a) =>
          a.batch === batch &&
          a.day === day &&
          lunchPeriod >= a.startPeriod &&
          lunchPeriod < a.startPeriod + a.duration
      );
      if (!busyAtLunch) lunchFreeBatchDays++;
    }
  }
  const lunchComplianceRate =
    totalBatchDays > 0 ? Math.round((lunchFreeBatchDays / totalBatchDays) * 100) : 100;

  const subjectById = new Map(subjects.map((subject) => [subject.id, subject]));
  const facultyById = new Map(facultyList.map((faculty) => [faculty.id, faculty]));
  const roomById = new Map(classrooms.map((room) => [room.id, room]));
  const preferenceScores = finalAllocations.flatMap((allocation) => {
    const subject = subjectById.get(allocation.subjectId);
    const faculty = facultyById.get(allocation.facultyId);
    const room = roomById.get(allocation.roomId);
    if (!subject || !faculty || !room) return [];
    return [scoreSlotPreference(
      faculty,
      allocation.day,
      allocation.startPeriod,
      allocation.duration,
      allocation.kind,
      room,
      subject,
      lunchPeriod
    )];
  });
  const averagePreference = preferenceScores.length > 0
    ? preferenceScores.reduce((sum, score) => sum + score, 0) / preferenceScores.length
    : 0;
  const softPreferenceScore = Math.max(
    0,
    Math.min(100, Math.round(averagePreference * 0.8 + lunchComplianceRate * 0.2 - facultyGiniCoefficient * 10))
  );

  const metrics: SolverMetrics = {
    elapsedMs,
    backtracks,
    nodesExplored,
    timedOut,
    softPreferenceScore,
    facultyGiniCoefficient,
    lunchComplianceRate,
  };

  const success = unallocated.length === 0 && clashes.length === 0;
  const message = success
    ? `Generated conflict-free timetable in ${elapsedMs}ms (${backtracks} backtracks).`
    : `Completed in ${elapsedMs}ms with ${unallocated.length} unallocated item(s) and ${clashes.length} clash(es) flagged.`;

  return {
    success,
    allocations: finalAllocations,
    unallocated,
    clashes,
    metrics,
    message,
  };
}
