import {
  Classroom,
  ClashViolation,
  DAYS_OF_WEEK,
  Faculty,
  PERIODS_PER_DAY,
  Subject,
  TimetableAllocation,
} from '../../../shared/types';

function periodsForAllocation(alloc: TimetableAllocation): number[] {
  if (!Number.isInteger(alloc.startPeriod) || !Number.isInteger(alloc.duration) || alloc.duration < 1 || alloc.duration > PERIODS_PER_DAY) {
    return [];
  }
  const list: number[] = [];
  for (let p = alloc.startPeriod; p < alloc.startPeriod + alloc.duration; p++) {
    list.push(p);
  }
  return list;
}

export function detectClashes(
  allocations: TimetableAllocation[],
  subjects: Subject[],
  facultyList: Faculty[],
  classrooms: Classroom[]
): ClashViolation[] {
  const clashes: ClashViolation[] = [];
  const subjectMap = new Map(subjects.map((s) => [s.id, s]));
  const facultyMap = new Map(facultyList.map((f) => [f.id, f]));
  const roomMap = new Map(classrooms.map((c) => [c.id, c]));

  // Track slot occupancy: `${day}-${period}` -> allocations
  const slotMap = new Map<string, TimetableAllocation[]>();
  const facultyHours = new Map<string, number>();

  for (const alloc of allocations) {
    const subj = subjectMap.get(alloc.subjectId);
    const fac = facultyMap.get(alloc.facultyId);
    const room = roomMap.get(alloc.roomId);
    const periods = periodsForAllocation(alloc);
    const sessionMismatch = Boolean(subj) && (
      alloc.facultyId !== subj!.facultyId ||
      alloc.batch !== subj!.batch ||
      (alloc.kind === 'LECTURE' && alloc.duration !== 1) ||
      (alloc.kind === 'LAB' && (subj!.labBlocksPerWeek === 0 || alloc.duration !== subj!.labBlockSize))
    );

    if (!subj || !fac || !room || sessionMismatch || !Number.isInteger(alloc.startPeriod) || !Number.isInteger(alloc.duration) || alloc.duration < 1 || alloc.duration > PERIODS_PER_DAY || (alloc.kind !== 'LECTURE' && alloc.kind !== 'LAB')) {
      clashes.push({
        id: `invalid-${String(alloc.id)}`,
        type: 'INVALID_ALLOCATION',
        severity: 'ERROR',
        message: `Clash: Allocation ${String(alloc.id)} references a missing resource or does not match its subject requirements.`,
        allocationIds: [String(alloc.id)],
        day: alloc.day,
        period: Number.isFinite(alloc.startPeriod) ? alloc.startPeriod : undefined,
        facultyId: alloc.facultyId,
        roomId: alloc.roomId,
        batch: alloc.batch,
      });
    }

    facultyHours.set(alloc.facultyId, (facultyHours.get(alloc.facultyId) ?? 0) + alloc.duration);

    // Out-of-bounds or invalid day/period
    if (
      !DAYS_OF_WEEK.includes(alloc.day) ||
      !Number.isInteger(alloc.startPeriod) ||
      !Number.isInteger(alloc.duration) ||
      alloc.startPeriod < 1 ||
      alloc.duration < 1 ||
      alloc.startPeriod + alloc.duration - 1 > PERIODS_PER_DAY
    ) {
      clashes.push({
        id: `oob-${alloc.id}`,
        type: 'OUT_OF_BOUNDS',
        severity: 'ERROR',
        message: `Clash: ${subj?.code ?? alloc.subjectId} exceeds 6-period day boundary on ${alloc.day} (P${alloc.startPeriod}–P${alloc.startPeriod + alloc.duration - 1}).`,
        allocationIds: [alloc.id],
        day: alloc.day,
        period: alloc.startPeriod,
        facultyId: alloc.facultyId,
        roomId: alloc.roomId,
        batch: alloc.batch,
      });
    }

    // Room capacity & equipment checks
    if (subj && room) {
      if (room.capacity < subj.batchSize) {
        clashes.push({
          id: `cap-${alloc.id}`,
          type: 'CAPACITY_EXCEEDED',
          severity: 'ERROR',
          message: `Clash: ${subj.code} (${subj.batch}, ${subj.batchSize} students) exceeds ${room.name} capacity (${room.capacity}) on ${alloc.day} P${alloc.startPeriod}.`,
          allocationIds: [alloc.id],
          day: alloc.day,
          period: alloc.startPeriod,
          facultyId: alloc.facultyId,
          roomId: room.id,
          batch: alloc.batch,
        });
      }

      if (alloc.kind === 'LAB' && !room.isLab) {
        clashes.push({
          id: `labroom-${alloc.id}`,
          type: 'LAB_ROOM_MISMATCH',
          severity: 'ERROR',
          message: `Clash: Lab session for ${subj.code} assigned to non-lab ${room.name} on ${alloc.day} P${alloc.startPeriod}.`,
          allocationIds: [alloc.id],
          day: alloc.day,
          period: alloc.startPeriod,
          facultyId: alloc.facultyId,
          roomId: room.id,
          batch: alloc.batch,
        });
      }

      const missingEq = subj.requiredEquipment.filter(
        (req) => !room.equipment.some((re) => re.toLowerCase() === req.toLowerCase())
      );
      if (missingEq.length > 0) {
        clashes.push({
          id: `eq-${alloc.id}`,
          type: 'MISSING_EQUIPMENT',
          severity: 'ERROR',
          message: `Clash: ${room.name} lacks required equipment (${missingEq.join(', ')}) for ${subj.code} on ${alloc.day} P${alloc.startPeriod}.`,
          allocationIds: [alloc.id],
          day: alloc.day,
          period: alloc.startPeriod,
          facultyId: alloc.facultyId,
          roomId: room.id,
          batch: alloc.batch,
        });
      }
    }

    // Faculty availability check per period
    if (fac) {
      const allowedPeriods = fac.availability[alloc.day] ?? [1, 2, 3, 4, 5, 6];
      if (!allowedPeriods || allowedPeriods.length === 0) {
        clashes.push({
          id: `favail-day-${alloc.id}`,
          type: 'FACULTY_UNAVAILABLE',
          severity: 'ERROR',
          message: `Clash: ${fac.name} is unavailable on ${alloc.day} for ${subj?.code ?? alloc.subjectId}.`,
          allocationIds: [alloc.id],
          day: alloc.day,
          period: alloc.startPeriod,
          facultyId: fac.id,
          batch: alloc.batch,
        });
      } else {
        const unavailablePeriods = periods.filter((p) => !allowedPeriods.includes(p));
        if (unavailablePeriods.length > 0) {
          clashes.push({
            id: `favail-per-${alloc.id}-${unavailablePeriods.join(',')}`,
            type: 'FACULTY_UNAVAILABLE',
            severity: 'ERROR',
            message: `Clash: ${fac.name} is unavailable during Period ${unavailablePeriods.join(', ')} on ${alloc.day} (${subj?.code ?? alloc.subjectId}).`,
            allocationIds: [alloc.id],
            day: alloc.day,
            period: unavailablePeriods[0],
            facultyId: fac.id,
            batch: alloc.batch,
          });
        }
      }
    }

    // Populate slot map for pairwise double-bookings
    for (const p of periods) {
      const key = `${alloc.day}-${p}`;
      const existing = slotMap.get(key) ?? [];
      existing.push(alloc);
      slotMap.set(key, existing);
    }
  }

  // Pairwise slot clashes: Faculty, Room, Batch
  const seenFacultyClash = new Set<string>();
  const seenRoomClash = new Set<string>();
  const seenBatchClash = new Set<string>();

  for (const [key, list] of slotMap.entries()) {
    if (list.length < 2) continue;
    const [dayStr, periodStr] = key.split('-');
    const day = dayStr as (typeof DAYS_OF_WEEK)[number];
    const period = Number(periodStr);

    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i];
        const b = list[j];

        // Faculty double-booked
        if (a.facultyId === b.facultyId) {
          const fac = facultyMap.get(a.facultyId);
          const roomB = roomMap.get(b.roomId);
          const roomA = roomMap.get(a.roomId);
          const pairKey = `fac-${[a.id, b.id].sort().join('|')}-${day}-${period}`;
          if (!seenFacultyClash.has(pairKey)) {
            seenFacultyClash.add(pairKey);
            clashes.push({
              id: pairKey,
              type: 'FACULTY_DOUBLE_BOOKED',
              severity: 'ERROR',
              message: `Clash: ${fac?.name ?? a.facultyId} already booked in ${roomB?.name ?? b.roomId} (vs ${roomA?.name ?? a.roomId}) on ${day} Period ${period}.`,
              allocationIds: [a.id, b.id],
              day,
              period,
              facultyId: a.facultyId,
              roomId: b.roomId,
              batch: a.batch,
            });
          }
        }

        // Room double-booked
        if (a.roomId === b.roomId) {
          const room = roomMap.get(a.roomId);
          const subjA = subjectMap.get(a.subjectId);
          const subjB = subjectMap.get(b.subjectId);
          const pairKey = `room-${[a.id, b.id].sort().join('|')}-${day}-${period}`;
          if (!seenRoomClash.has(pairKey)) {
            seenRoomClash.add(pairKey);
            clashes.push({
              id: pairKey,
              type: 'ROOM_DOUBLE_BOOKED',
              severity: 'ERROR',
              message: `Clash: ${room?.name ?? a.roomId} double-booked by ${subjA?.code ?? a.subjectId} (${a.batch}) and ${subjB?.code ?? b.subjectId} (${b.batch}) on ${day} Period ${period}.`,
              allocationIds: [a.id, b.id],
              day,
              period,
              roomId: a.roomId,
            });
          }
        }

        // Batch double-booked
        if (a.batch === b.batch) {
          const subjA = subjectMap.get(a.subjectId);
          const subjB = subjectMap.get(b.subjectId);
          const pairKey = `batch-${[a.id, b.id].sort().join('|')}-${day}-${period}`;
          if (!seenBatchClash.has(pairKey)) {
            seenBatchClash.add(pairKey);
            clashes.push({
              id: pairKey,
              type: 'BATCH_DOUBLE_BOOKED',
              severity: 'ERROR',
              message: `Clash: Batch ${a.batch} has overlapping classes (${subjA?.code ?? a.subjectId} and ${subjB?.code ?? b.subjectId}) on ${day} Period ${period}.`,
              allocationIds: [a.id, b.id],
              day,
              period,
              batch: a.batch,
            });
          }
        }
      }
    }
  }

  // Faculty weekly workload limit check
  for (const [facId, totalHours] of facultyHours.entries()) {
    const fac = facultyMap.get(facId);
    if (fac && totalHours > fac.maxWeeklyHours) {
      clashes.push({
        id: `wk-${facId}`,
        type: 'WORKLOAD_EXCEEDED',
        severity: 'ERROR',
        message: `Clash: ${fac.name} assigned ${totalHours}h/week, exceeding max workload limit of ${fac.maxWeeklyHours}h/week.`,
        allocationIds: allocations.filter((a) => a.facultyId === facId).map((a) => a.id),
        facultyId: facId,
      });
    }
  }

  for (const subject of subjects) {
    const subjectAllocations = allocations.filter((allocation) => allocation.subjectId === subject.id);
    const sessionGroups: Array<{ kind: 'LECTURE' | 'LAB'; expected: number }> = [
      { kind: 'LECTURE', expected: subject.lectureHoursPerWeek },
      { kind: 'LAB', expected: subject.labBlocksPerWeek },
    ];
    for (const group of sessionGroups) {
      const matching = subjectAllocations.filter((allocation) => allocation.kind === group.kind);
      if (matching.length > group.expected) {
        const extras = matching.slice(group.expected);
        clashes.push({
          id: `excess-${subject.id}-${group.kind.toLowerCase()}`,
          type: 'INVALID_ALLOCATION',
          severity: 'ERROR',
          message: `Clash: ${subject.code} has ${matching.length} ${group.kind.toLowerCase()} sessions scheduled, but only ${group.expected} are required.`,
          allocationIds: extras.map((allocation) => allocation.id),
          batch: subject.batch,
        });
      }
    }
  }

  return clashes;
}
