# ClassClockwork: ZeroClash Sprint

ClassClockwork creates and edits conflict-aware college timetables. It includes a backtracking constraint solver with Minimum Remaining Values ordering, an interactive 5-day by 6-period grid, resource management, batch and faculty views, an allocation auditor, and print and calendar export.

## Requirements

- Node.js 20 or newer
- npm

## Start the application

Open two terminals from this project folder.

In the first terminal, start the backend:

```bash
cd backend
npm install
npm run dev
```

The API runs at `http://127.0.0.1:4000`.

In the second terminal, start the frontend:

```bash
cd frontend
npm install
npm run dev
```

Open `http://localhost:5173` in your browser. The Vite development server forwards API requests to the local backend.

The frontend can load a bundled demo and keep edits in browser storage if the backend is unavailable. Automatic timetable generation and server-side persistence need the backend running.

## Use the app

1. Choose **6-Subj Demo** for the quick demonstration or **8-Subj CS Preset** for the larger dataset.
2. Manage subjects, faculty, and rooms in **Academic Resource Manager**. Use **Edit** to change a resource or the trash icon to remove it. Faculty availability is set by toggling periods 1 through 6 for each weekday.
3. Choose **Generate Timetable**. Labs are placed as continuous blocks, while the solver checks faculty availability and workload, room capacity and equipment, and batch, room, and faculty overlaps.
4. Drag an allocation to another day or period to see the auditor flag any conflicts. Lock an allocation to keep it in place during the next generation.
5. Switch between batch and faculty views. Export an `.ics` calendar file or use **Print / PDF** to save a printable schedule.

If the constraints cannot all be satisfied, the app lists unallocated sessions and explains that the solver could not place them. It does not report a partial schedule as conflict-free.

## Build for production

Build the backend and frontend separately:

```bash
cd backend
npm install
npm run build
```

```bash
cd frontend
npm install
npm run build
```

The backend stores timetable datasets in a local JSON file under `backend/data/`. That file is ignored by Git.

## Project layout

- `frontend/` — React, TypeScript, Tailwind CSS, timetable views, and resource forms
- `backend/` — Express API, JSON persistence, clash auditor, and CSP solver
- `shared/` — types shared by the frontend and backend
